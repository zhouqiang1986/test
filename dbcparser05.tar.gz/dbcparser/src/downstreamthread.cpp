#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "downstreamthread.hpp"
#include "lcmdownheader.hpp"

downThread::downThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

downThread::~downThread() {

}

void downThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  LongitudeAccHandler LongitudeAccObject(pdbc_lcm);
  lcm.subscribe("LongitudeAccDOWN", &LongitudeAccHandler::handleMessage, &LongitudeAccObject);
  LateralAcceHandler  LateralAcceAccObject(pdbc_lcm);
  lcm.subscribe("LateralAcceDOWN", &LateralAcceHandler::handleMessage, &LateralAcceAccObject);
  while(0 == lcm.handle());
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }*/
}
