#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "upstreamthread.hpp"
#include "upstreamlcm.hpp"

upThread::upThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

upThread::~upThread() {

}

void upThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  uplcmHandler handleObject(pdbc_lcm);
  lcm.subscribe("UPSTREAMDBCREC", &uplcmHandler::handleMessage, &handleObject);
  while(0 == lcm.handle());
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("upThread is running...\n");
    sleep(1);
  }
  */
}
