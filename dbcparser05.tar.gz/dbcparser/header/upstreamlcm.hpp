#ifndef UPSTREAMLCM_HPP_
#define UPSTREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>

#include "dbciterator.hpp"
#include "lcmtypes/buffer_data_t.hpp"

class uplcmHandler {
public:
  uplcmHandler() {};
  uplcmHandler(DBCIterator *pdbc);
  ~uplcmHandler() {};
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::buffer_data_t *msg);

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
};

#endif
