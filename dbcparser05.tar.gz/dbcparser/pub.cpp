#include <lcm/lcm-cpp.hpp>
#include "lcmtypes/buffer_data_t.hpp"
#include <iostream>
int main(int argc, char ** argv)
{
     lcm::LCM lcm;
     if(!lcm.good())
         return 1;

     lcmtypes::buffer_data_t my_data;
     my_data.utime = 4;
     my_data.data_length = 13;

     my_data.data.resize(my_data.data_length);
//     for(int i = 0; i < my_data.data_length; i++)
 //   {
 /*
       my_data.data[0] = 0x09;
       my_data.data[1] = 0x00;
       my_data.data[2] = 0x00;
       my_data.data[3] = 0x02;
       my_data.data[4] = 0x92;
       my_data.data[5] = 0x00;
       my_data.data[6] = 0x1C;
       my_data.data[7] = 0x00;
       my_data.data[8] = 0xDF;
       */
       my_data.data[0] = 0x0c;
       my_data.data[1] = 0x00;
       my_data.data[2] = 0x00;
       my_data.data[3] = 0x03;
       my_data.data[4] = 0x06;

       my_data.data[5] = ((uint16_t)(-10))&0xff;
       my_data.data[6] = 0x86;
       my_data.data[7] = 0x79;
       my_data.data[8] = 0x00;
       my_data.data[9] = 0x39;
       my_data.data[10] = 0x83;
       my_data.data[11] = 0x7b;
       lcm.publish("UPSTREAMDBCREC", &my_data);
       //lcm.publish("UPSTREAMDBCREC", &my_data);
//     }



     return 0;
}
