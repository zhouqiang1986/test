#include <lcm/lcm-cpp.hpp>
#include <stdio.h>
#include "lcmtypes/buffer_data_t.hpp"
class Handler
    {
         public:
             ~Handler() {}

            void handleMessage(const lcm::ReceiveBuffer* rbuf,
                    const std::string& chan,
                    const lcmtypes::buffer_data_t* rdata)
            {
              //int32_t pkg_len;
              //uint8_t  dataLen;
              //uint32_t dataId;
              //uint64_t dataData;

              //Message msg;
              //uint8_t *tData = new uint8_t[13];
              //uint8_t tData[13];
              printf("utime:%ld\n", rdata->utime);
              printf("data_length:%d\n", rdata->data_length);
              for(int i=0; i < 6; i++)
              {
                printf("data[%d]: %d \n", i, rdata->data[i]);
              }


              /*
              pkg_len = rdata->data_length;
              for(int i=0; i<pkg_len; i++)
              {
                printf("Received message on channel \"%s\":\n", chan.c_str());
                for(int j=0; j<13; j++) {
                  tData[j] = rdata->data[j + i*13];
                  printf("dataLen:%d\n", tData[j]);
                }*/
              /*
                int i;
                printf("Received message on channel \"%s\":\n", chan.c_str());
                printf("  timestamp   = %lld\n", (long long)msg->timestamp);
                printf("  position    = (%f, %f, %f)\n",
                        msg->position[0], msg->position[1], msg->position[2]);
                printf("  orientation = (%f, %f, %f, %f)\n",
                        msg->orientation[0], msg->orientation[1],
                        msg->orientation[2], msg->orientation[3]);
                printf("  ranges:");
                for(i = 0; i < msg->num_ranges; i++)
                    printf(" %d", msg->ranges[i]);
                printf("\n");
                printf("  name        = '%s'\n", msg->name.c_str());
                printf("  enabled     = %d\n", msg->enabled); */
            }
    };
int main(int argc, char ** argv)
{
     lcm::LCM lcm;
     if(!lcm.good())
         return 1;

     Handler handlerObject;
     lcm.subscribe("UPSTREAMDBCREC", &Handler::handleMessage, &handlerObject);
     while(0 == lcm.handle());

     return 0;
}
