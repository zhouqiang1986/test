#ifndef STREAMTHREAD_HPP_
#define STREAMTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>
#include <boost/thread/mutex.hpp>
#include <utility>
#include <map>
#include "Thread.hpp"

#define canObj(name) (Can##name##Obj)

class streamThread : public NThread {

  typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
  typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

public:
  streamThread();
  virtual ~streamThread();

  virtual void run() override;

private:
  lcm::LCM lcm;
  //DBCIterator *pdbc_lcm;
  boost::thread_group threadGp;

};

#endif
