#ifndef CANSTREAM_HPP_
#define CANSTREAM_HPP_

#include <lcm/lcm-cpp.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <mutex>
#include <utility>
#include <map>
#include <queue>

#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>
#include <sstream>
#include <sys/epoll.h>
#include <stdlib.h>
#include <string.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>

#include "lcmtypes/buffer_data_t.hpp"

enum class Direction {
  UPSTREAM,
  DOWNSTREAM,
  BIDIRECTION
};

class Canstream {

  typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
  typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

public:
  Canstream(uint8_t port, Direction dir, std::string pubChan);
  virtual ~Canstream();

private:
  lcm::LCM lcm;
  //DBCIterator *pdbc_lcm;
  boost::thread_group threadGp;
  int cansock_fd;
  int epoll_fd;
  struct epoll_event events[1];
  std::string pubChan;
  std::queue<struct can_frame> upQueue;

private:
  int64_t getCurrentTime();

public:
  void upCan_sub();
  void upCan_pub();
  void downCan_sub(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *rdata);
};

#endif
