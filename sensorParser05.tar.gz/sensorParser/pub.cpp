#include <lcm/lcm-cpp.hpp>
#include <iostream>
#include <unistd.h>

#include "lcmtypes/buffer_data_t.hpp"

int main(int argc, char ** argv)
{
     lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
     if(!lcm.good())
         return 1;

     lcmtypes::buffer_data_t my_data;
     my_data.utime = 4;
     my_data.data_length = 26;
     my_data.data.resize(my_data.data_length);
       my_data.data[0] = 0x0d;
       my_data.data[1] = 0x00;
       my_data.data[2] = 0x00;
       my_data.data[3] = 0x05;
       my_data.data[4] = 0x00;
       //my_data.data[3] = 0x02;
       //my_data.data[4] = 0x45;
       my_data.data[5] = 0x9c;
       my_data.data[6] = 0x20;
       my_data.data[7] = 0x00;
       my_data.data[8] = 0x95;
       my_data.data[9] = 0x00;
       my_data.data[10] = 0x00;
       my_data.data[11] = 0x9a;
       my_data.data[12] = 0xb4;
       /*
       my_data.data[13] = 0x0d;
       my_data.data[14] = 0x00;
       my_data.data[15] = 0x00;
       my_data.data[16] = 0x05;
       my_data.data[17] = 0x40;
       //my_data.data[16] = 0x02;
       //my_data.data[17] = 0x31;
       my_data.data[18] = 0x09;
       my_data.data[19] = 0x00;
       my_data.data[20] = 0x11;
       my_data.data[21] = 0x95;
       my_data.data[22] = 0x00;
       my_data.data[23] = 0x00;
       my_data.data[24] = 0x00;
       my_data.data[25] = 0x00;*/
       while(1) {
        usleep(10000);//100hz
        //lcm.publish("CAN_ESR_REAR_DAOYUAN_RAW_DATA", &my_data);
        lcm.publish("ESR_REAR_RAW_DATA", &my_data);
        //lcm.publish("CAN_MOBILE_TX", &my_data);
        //lcm.publish("CAN_RSDS_RAW_DATA", &my_data);
      }


     return 0;
}
