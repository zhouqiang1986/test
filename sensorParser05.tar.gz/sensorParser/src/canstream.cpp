#include "canstream.hpp"

Canstream::Canstream(uint8_t port, Direction dir, std::string pubChan) {
  //pdbc_lcm = pdbc;
  this->pubChan = pubChan;
  struct sockaddr_can addr;
  struct ifreq ifr;
  cansock_fd = socket(PF_CAN, SOCK_RAW, CAN_RAW);
  char str[10];
  char sstr[10];
  sprintf(str, "%d", port);
  sprintf(sstr, "%s%s", "can", str);
  strcpy(ifr.ifr_name, sstr);
  ioctl(cansock_fd, SIOCGIFINDEX, &ifr);
  addr.can_family = AF_CAN;
  addr.can_ifindex = ifr.ifr_ifindex;
  bind(cansock_fd, (struct sockaddr*)&addr, sizeof(addr));
  int loopback = 0;
  setsockopt(cansock_fd, SOL_CAN_RAW, CAN_RAW_LOOPBACK, &loopback, sizeof(loopback));
  int ro = 0;
  setsockopt(cansock_fd, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS, &ro, sizeof(ro));
  switch (dir) {
    case Direction::UPSTREAM :
      break;
    case Direction::DOWNSTREAM :
      setsockopt(cansock_fd, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);
      break;
    case Direction::BIDIRECTION :
      break;
  }

  struct epoll_event ev;
  epoll_fd = epoll_create(1);
  ev.data.fd = cansock_fd;
  ev.events = EPOLLIN;
  epoll_ctl(epoll_fd, EPOLL_CTL_ADD, cansock_fd, &ev);
}

Canstream::~Canstream() {
  close(cansock_fd);
}

int64_t Canstream::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void Canstream::upCan_sub() {
  int nbytes;
  int nfds;
  struct can_frame upframe;
  while(1) {
    nfds = epoll_wait(epoll_fd, events, 1, -1);
    for(int i=0; i<nfds; ++i) {
      if(events[i].events&EPOLLIN) {
        nbytes = read(cansock_fd, &upframe, sizeof(upframe));
        if(nbytes == sizeof(upframe)) {
          upQueue.push(upframe);
        }
      }
    }
  }
}

void Canstream::upCan_pub() {
  lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
  if(!lcm.good())
  {
    return ;
  }
  struct can_frame upframe;
  while(1) {
    usleep(20000);//50Hz

    if(!upQueue.empty()) {
      lcmtypes::buffer_data_t buffer_data;
      do{
        upframe = upQueue.front();
        buffer_data.data.push_back(8);
        buffer_data.data.push_back((upframe.can_id>>24)&0xff);
        buffer_data.data.push_back((upframe.can_id>>16)&0xff);
        buffer_data.data.push_back((upframe.can_id>>8)&0xff);
        buffer_data.data.push_back((upframe.can_id>>0)&0xff);
        for(int i=0; i<upframe.can_dlc; i++) {
          buffer_data.data.push_back(upframe.data[i]);
        }
        for(int j=0; j< 8-upframe.can_dlc; j++) {
          buffer_data.data.push_back(0x00);
        }
        upQueue.pop();
      } while(!upQueue.empty());
      buffer_data.utime = getCurrentTime();
      buffer_data.data_length = buffer_data.data.size();
      lcm.publish(pubChan, &buffer_data);
    } else {
      continue;
    }
  }
}

void Canstream::downCan_sub(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *rdata)
{
  struct can_frame downframe;
  for(int i=0; i<rdata->data_length/13; i++) {
    downframe.can_dlc = 8;
    downframe.can_id = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    for(int k=0; k<8; k++) {
      downframe.data[k] = rdata->data[5+k+i*13];
    }
    write(cansock_fd, &downframe, sizeof(downframe));
  }
}
