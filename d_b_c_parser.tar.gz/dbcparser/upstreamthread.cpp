#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "header/upstreamthread.hpp"

upThread::upThread() {

}

upThread::~upThread() {

}

void upThread::run() {

  while(!this->isInterrupted())
  {
    printf("up_thread is running\n");
    sleep(1);
  }
}
