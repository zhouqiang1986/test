#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "header/downstreamthread.hpp"

downThread::downThread() {

}

downThread::~downThread() {

}

void downThread::run() {

  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }
}
