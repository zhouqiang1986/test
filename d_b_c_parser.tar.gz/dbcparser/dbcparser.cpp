#include <iostream>
#include <stdexcept>
#include <thread>
#include <stdio.h>
#include <unistd.h>

#include "header/dbciterator.hpp"
#include "header/downstreamthread.hpp"
#include "header/upstreamthread.hpp"

const std::string usage = ""
        "example:\n"
        "   ./dbcparser  /home/dbc_directory\n"
        "   dbc_directory means the filePath of dbc files\n";


int main(int argc, char *argv[])
{

  if(argc < 2) {
    std::cout << usage << std::endl;
    return 0;
  }

  try {
    DBCIterator dbc(argv[1]);
    for(auto message : dbc) {
        std::cout << message.getName() << " " << message.getId() << std::endl;
        for(auto sig : message) {
            std::cout << "Signal: " << sig.getName() << "  ";
            std::cout << "To: ";
            for (auto to : sig.getTo()) {
                std::cout << to << ", ";
            }
            std::cout << sig.getStartbit() << "," << sig.getLength() << std::endl;
            std::cout << "(" << sig.getFactor() << ", " << sig.getOffset() << ")" << std::endl;
            std::cout << "[" << sig.getMinimum() << "," << sig.getMaximum() << "]" << std::endl;
            if (sig.getMultiplexor() == Multiplexor::MULTIPLEXED) {
                std::cout << "#" << sig.getMultiplexedNumber() << "#" << std::endl;
            } else if (sig.getMultiplexor() == Multiplexor::MULTIPLEXOR) {
                std::cout << "+Multiplexor+" << std::endl;
            }
            std::cout << std::endl;
        };
    }
  } catch (std::invalid_argument& ex) {
    std::cout << ex.what() << std::endl;
  }
  /*
  //step2
  downThread downTh;
  downTh.start();
  upThread upTh;
  upTh.start();
  downTh.join();
  upTh.join();
  std::this_thread::sleep_for(std::chrono::seconds(2));
  */
std::cout << "这是主线程" << std::endl;

  return 0;
}
