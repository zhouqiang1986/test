#include  "upstreamlcm.hpp"
#include "signal.hpp"

lcmHandler::lcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

void lcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }
  printf("utime:%ld\n", rdata->utime);
                printf("data_length:%d\n", rdata->data_length);
                for(int i=0; i < 6; i++)
                {
                 printf("data[%d]: %d \n", i, rdata->data[i]);
               }
  /*
  int32_t pkg_len;
  uint8_t  dataLen;
  uint32_t dataId;
  uint64_t dataData;

  Message msg;
  uint8_t tData[13] = {0,1,1,1,1,1,1,1,1,1,1,1,1};

  pkg_len = rdata->data_length;
  for(int i=0; i<pkg_len; i++)
  {

    for(int j=0; j<13; j++) {
      tData[j] = rdata->data[j + i*13];
    }
    dataLen = tData[0];
    dataId = (tData[1]<<24) | (tData[2]<<16) | (tData[3]<<8) | tData[4];
    uint8_t *tmpData = new uint8_t[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = tData[5+k];
    }
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        for(auto tSg : tMsg) {
          uint64_t realValue;
          if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
            uint8_t  head_len = tSg.getStartbit()%8+1;
            uint8_t  data_len = tSg.getLength();
            uint8_t  data_num = tSg.getStartbit()/8;
            uint8_t  next_len =  data_len-head_len;
            realValue = (tmpData[data_num]<<next_len)&(2^data_len-1);
            for(int m=0; m<(data_len-head_len)/8; m++) {
              next_len -= 8;
              realValue |= (tmpData[data_num+m+1]<<next_len);
            }
            realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);

          } else {
            uint8_t  head_len = 8-tSg.getStartbit()%8;
            uint8_t  data_len = tSg.getLength();
            uint8_t  data_num = tSg.getStartbit()/8;
            uint8_t  next_len =  head_len;
            realValue = tmpData[data_num]>>tSg.getStartbit()%8;
            for(int n=0; n<(data_len-head_len)/8; n++) {
              realValue |= tmpData[data_num+n+1]<<next_len;
              next_len += 8;
            }
            realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;

          }
          //printf(" realValue = %lld\n", (unsigned long unsigned long)realValue);
        }
      }
      //std::cout << tMsg.getName() << " " << tMsg.getId() << std::endl;
    } */

    //printf("dataLen:%d\n", dataLen);
    //printf("dataLen:%x\n", dataId);
    //printf("dataLen:%x\n", dataData);
    //std::cout << "dataLen:" <<std::hex<< (int)dataLen << std::endl;
    //std::cout << "dataId:" << std::hex<< dataLen << std::endl;
    //std::cout << "dataData:" << std::hex<< dataLen << std::endl;

  //}


  //lcm.publish("UPSTREAMDBCSED", rdata);
}
