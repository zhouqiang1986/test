#ifndef DOWNTHREAD_HPP_
#define DOWNTHREAD_HPP_

#include "Thread.hpp"

class downThread : public NThread {

public:
  downThread();
  virtual ~downThread();

  virtual void run() override;

};

#endif
