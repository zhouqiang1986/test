#ifndef CANSTREAM_HPP_
#define CANSTREAM_HPP_

#include <lcm/lcm-cpp.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <mutex>
#include <utility>
#include <map>
#include "dbciterator.hpp"

class Canstream {

  typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
  typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

  typedef std::map<std::string, std::vector<Message>> messages_t;
  typedef std::map<std::string, std::vector<Message>>::iterator msgIte_t;

public:
  Canstream(DBCIterator *pdbc);
  virtual ~Canstream();

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  boost::thread_group threadGp;
  int cansock_fd;

public:
  void upCan_sub();
  void upCan_pub();
  void downCan_sub();
  void downCan_pub();

};

#endif
