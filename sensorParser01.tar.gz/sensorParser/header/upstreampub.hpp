#ifndef UPSTREAMPUB_HPP_
#define UPSTREAMPUB_HPP_

#include <lcm/lcm-cpp.hpp>
#include <mutex>

#include "Thread.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"

class upstreampub : public NThread {

public:
  upstreampub(lcmtypes::buffer_dbc_t *buffer_dbc, std::mutex *up_mutex);
  virtual ~upstreampub();

  virtual void run() override;

private:
  lcm::LCM lcm;
  lcmtypes::buffer_dbc_t *buffer_dbc;
  std::mutex *up_mutex;

private:
  int64_t getCurrentTime();

};

#endif
