#ifndef STREAMTHREAD_HPP_
#define STREAMTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>
#include <boost/thread/mutex.hpp>
#include <utility>
#include <map>
#include "Thread.hpp"
#include "dbciterator.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>

class streamThread : public NThread {

  typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
  typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

  typedef std::map<std::string, std::vector<Message>> messages_t;
  //typedef std::map<std::string, std::vector<Message>>::iterator msgIte_t;
  typedef std::map<std::string, std::map<uint32_t, std::map<std::string, struct SSignal>>>::iterator msgsDict_t;

public:
  streamThread() {};
  streamThread(DBCIterator *pdbc);
  virtual ~streamThread();

  virtual void run() override;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  boost::thread_group threadGp;

};

#endif
