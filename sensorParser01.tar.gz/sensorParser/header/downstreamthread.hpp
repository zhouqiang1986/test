#ifndef DOWNTHREAD_HPP_
#define DOWNTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>
#include <boost/thread/mutex.hpp>
#include <utility>
#include <map>
#include "Thread.hpp"
#include "dbciterator.hpp"

class downThread : public NThread {

  typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
  typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

  typedef std::map<std::string, std::vector<Message>> messages_t;
  typedef std::map<std::string, std::vector<Message>>::iterator msgIte_t;

public:
  downThread(DBCIterator *pdbc);
  virtual ~downThread();

  virtual void run() override;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  boost::thread_group threadGp;

};

#endif
