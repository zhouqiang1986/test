#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>

#include <stdlib.h>
#include <string.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>

#include "canstream.hpp"

Canstream::Canstream(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;

  std::cout<<"Canstream init"<<std::endl;
  struct sockaddr_can addr;
  struct ifreq ifr;
  struct can_frame frame;
  cansock_fd = socket(PF_CAN, SOCK_RAW, CAN_RAW);
  strcpy(ifr.ifr_name, "can0");
  ioctl(cansock_fd, SIOCGIFINDEX, &ifr);
  addr.can_family = AF_CAN;
  addr.can_ifindex = ifr.ifr_ifindex;
  bind(cansock_fd, (struct sockaddr*)&addr, sizeof(addr));
  int loopback = 0;
  setsockopt(cansock_fd, SOL_CAN_RAW, CAN_RAW_LOOPBACK, &loopback, sizeof(loopback));
}

Canstream::~Canstream() {

}

void Canstream::upCan_sub() {
  while(1) {
    usleep(1000000);
    std::cout<<"upCan_sub..."<<std::endl;
  }
}

void Canstream::upCan_pub() {
  while(1) {
    usleep(1000000);
    std::cout<<"upCan_pub..."<<std::endl;
  }
}

void Canstream::downCan_sub() {
  while(1) {
    usleep(1000000);
    std::cout<<"downCan_sub..."<<std::endl;
  }
}

void Canstream::downCan_pub() {
  while(1) {
    usleep(1000000);
    std::cout<<"downCan_pub..."<<std::endl;
  }
}
