#include  "downstreamlcm.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"

#include <math.h>

downlcmHandler::downlcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

int64_t downlcmHandler::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}
/*
void downlcmHandler::rsds_pub() {
  while(1) {
    printf("rsds_pub is running\n");
    usleep(50000);//20Hz

  }
}*/

void downlcmHandler::todaoyuan_pub() {
  while(1) {
    printf("todaoyuan_pub is running\n");
    usleep(50000);//20Hz
  }
}

void downlcmHandler::topowercon_pub() {
  while(1) {
    printf("topowercon_pub is running\n");
    usleep(50000);//20Hz
  }
}

void downlcmHandler::tovehcon_pub() {
  while(1) {
    printf("tovehcon_pub is running\n");
    usleep(50000);//20Hz
  }
}
/*
void downlcmHandler::mobileeyeifo_pub() {
  while(1) {
    printf("mobileeyeifo_pub is running\n");
    usleep(100000);//10Hz
  }
}*/

void downlcmHandler::tocamera_pub() {
  uint8_t count = 0;
  while(1) {
    //printf("tocamera_pub is running\n");
    usleep(50000);//20Hz

  }
}

void downlcmHandler::downstream_pub() {
  while(1) {
    //printf("downstreampub is running\n");
    usleep(50000);//20Hz
    down_mutex[0].lock();
    buffer_data.utime = getCurrentTime();
    buffer_data.data_length = buffer_data.data.size();
    lcm.publish("DOWNSTREAMDBCSED", &buffer_data);
    buffer_data.data.clear();
    buffer_data.data_length = buffer_data.data.size();
    down_mutex[0].unlock();
  }
}

void downlcmHandler::dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue) {
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue>>next_len)<<(tSg.getStartbit()%8+1-head_len);
    if(next_len >= 8) {
      for(int i=0; i<(data_len-head_len)/8; i++) {
        next_len -= 8;
        tData[data_num+i+1] = (hexValue>>next_len)&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= (hexValue&((uint64_t)pow(2,next_len)-1))<<(8-next_len);
    }
  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue&((uint64_t)pow(2,head_len)-1))<<(tSg.getStartbit()%8);
    if(next_len >= 8) {
      for(int j=0; j<(data_len-head_len)/8; j++) {
        next_len -= 8;
        tData[data_num+j+1] = (hexValue>>(head_len+j*8))&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= hexValue>>(data_len-next_len);
    }
  }
}
/*
void downlcmHandler::rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                       const std::string& chan,
                       const lcmtypes::buffer_data_t *msg)
{

}*/

void downlcmHandler::todaoyuanHandleMessage(const lcm::ReceiveBuffer *buf,
                          const std::string& chan,
                          const lcmtypes::buffer_data_t *msg)
{

}

void downlcmHandler::topowerconHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void downlcmHandler::tovehconHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}
/*
void downlcmHandler::mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}*/

void downlcmHandler::tocameraHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *rdata)
{
  /*
  std::vector<uint8_t> tBuf_data;
  for(auto tMsg : *pdbc_lcm) {
    for(int i=0; i<rdata->data_length; i++) {
      if(tMsg.getId() == rdata->data[i].id) {
        tBuf_data.push_back(8);
        tBuf_data.push_back((tMsg.getId()>>24)&0xff);
        tBuf_data.push_back((tMsg.getId()>>16)&0xff);
        tBuf_data.push_back((tMsg.getId()>>8)&0xff);
        tBuf_data.push_back(tMsg.getId()&0xff);
        uint8_t tData[8] = {0};
        for(auto tSg : tMsg) {
          std::string sgName = tSg.getName();
          uint64_t hexValue;
          for(int j=0; j<rdata->data[i].sigCnt; j++) {
            if(0 == sgName.compare(rdata->data[i].sigMap[j].sigName)) {
              hexValue = (rdata->data[i].sigMap[j].sigValue-tSg.getOffset())/tSg.getFactor();
              dorConvert(tSg, tData, hexValue);
            }
          }
        }
        for(int k=0; k<8; k++) {
          tBuf_data.push_back(tData[k]);
        }
      }
    }

  }

  down_mutex[0].lock();
  buffer_data.data.clear();
  buffer_data.data.insert(buffer_data.data.end(), tBuf_data.begin(), tBuf_data.end());
  down_mutex[0].unlock();
  */
}

void downlcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_dbc_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  int32_t pkg_len = rdata->data_length;
      /*
      std::vector<uint8_t> tBuf_data;
      for(auto tMsg : *pdbc_lcm) {
        for(int i=0; i<rdata->data_length; i++) {
          if(tMsg.getId() == rdata->data[i].id) {
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              for(int j=0; j<rdata->data[i].sigCnt; j++) {
                if(0 == sgName.compare(rdata->data[i].sigMap[j].sigName)) {
                  hexValue = (rdata->data[i].sigMap[j].sigValue-tSg.getOffset())/tSg.getFactor();
                  dorConvert(tSg, tData, hexValue);
                }
              }
            }
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          }
        }

      }

      down_mutex[0].lock();
      buffer_data.data.clear();
      buffer_data.data.insert(buffer_data.data.end(), tBuf_data.begin(), tBuf_data.end());
      down_mutex[0].unlock();
      */

}
