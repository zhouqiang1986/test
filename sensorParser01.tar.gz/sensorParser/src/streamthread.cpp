#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>

#include "upstreamthread.hpp"
#include "upCanstream.hpp"

upstreamThread::upstreamThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

upstreamThread::~upstreamThread() {

}

void upstreamThread::run() {

  upCanstream upCanObjs(pdbc_lcm);
  threadGp.create_thread(boost::bind(&upCanstream::upCan_sub, &upCanObjs));
  threadGp.create_thread(boost::bind(&upCanstream::upCan_pub, &upCanObjs));
  //downlcmHandler downlcmHandlerObject(pdbc_lcm);
  //lcm.subscribe("DOWNSTREAMDBCREC", &downlcmHandler::handleMessage, &downlcmHandlerObject);
/*  cfgListIte_t cfgite;
  msgIte_t msgite;
  for(msgite=pdbc_lcm->messageList.begin(); msgite != pdbc_lcm->messageList.end(); msgite++) {
    if((cfgite=pdbc_lcm->cfgList->find(msgite->first)) != pdbc_lcm->cfgList->end()) {
      if(cfgite->second.find("lcm_rx_channel") != cfgite->second.end()) {
        std::string lcm_channel = cfgite->second.find("lcm_rx_channel")->second;
        if(!lcm_channel.empty() && lcm_channel.size()>1) {
          if(msgite->first == "Sensor_CAN_MOBILE_RX") {
            std::cout<<"!channel:"<<lcm_channel<<"   size:"<<lcm_channel.size()<<std::endl;
            //lcm.subscribe(lcm_channel, &downlcmHandler::tocameraHandleMessage, &downlcmHandlerObject);
            threadGp.create_thread(boost::bind(&downlcmHandler::tocamera_pub, &downlcmHandlerObject));
          }

        }
      }
    }
  }*/
  //lcm.subscribe("CAN_RSDS_RAW_DATA", &downlcmHandler::rsdsHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_DAOYUAN_CMD", &downlcmHandler::todaoyuanHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_POWER_CONTROL", &downlcmHandler::topowerconHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_VEHICLE_CONTROL", &downlcmHandler::tovehconHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("CAN_MOBILE_TX", &downlcmHandler::mobileeyeifoHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_CAMERA", &downlcmHandler::tocameraHandleMessage, &downlcmHandlerObject);
  //threadGp.create_thread(boost::bind(&downlcmHandler::rsds_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::todaoyuan_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::topowercon_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::tovehcon_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::mobileeyeifo_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::tocamera_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&uplcmHandler::upstream_pub, &uplcmHandlerObject));

  threadGp.join_all();
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }*/
}
