#include <iostream>
#include <stdexcept>
#include <thread>
#include <stdio.h>
#include <unistd.h>

#include "dbciterator.hpp"
#include "rconfig.hpp"
#include "upstreamthread.hpp"

const std::string usage = ""
        "example:\n"
        "   ./dbcparser  /home/dbc_directory\n"
        "   dbc_directory means the filePath of dbc files\n";


int main(int argc, char *argv[])
{
  /*
  if(argc < 2) {
    std::cout << usage << std::endl;
    return 0;
  }*/

  try {
    rConfig rconfig;
    rconfig.ReadConfig("../dbc/setting_CHVV6.ini");
    //std::map<std::string, std::map<std::string, std::string>>::iterator ite;
    //for(ite=rconfig.settings_.begin(); ite != rconfig.settings_.end(); ite++) {
      //std::cout<<ite->first<<ite->second.size()<<std::endl;
      //std::string lcm_channel = ite->second.find("lcm_channel")->second;
    //}


      //std::cout<<"channel:"<<lcm_channel<<"size:"<<lcm_channel.size()<<std::endl;
      //cnt++;
      //std::cout<<"!cnt:"<<std::hex<<(int)cnt<<std::endl;
      //if(!lcm_channel.empty()) {

        //std::cout<<"!channel:"<<lcm_channel<<std::endl;
        //lcm.subscribe(lcm_channel, &uplcmHandler::mobileeyeifoHandleMessage, &uplcmHandlerObject);
      //}

    DBCIterator dbc(&rconfig.settings_);
    /*
    std::map<std::string, std::map<uint32_t, std::map<std::string, struct SSignal>>>::iterator ite;
    std::map<uint32_t, std::map<std::string, struct SSignal>>::iterator iteMsg;
    std::map<std::string, struct SSignal>::iterator iteSIg;
    for(ite = dbc.msgsDict.begin(); ite != dbc.msgsDict.end(); ite++) {
      std::cout<<"*********"<<ite->first<<"********"<<std::endl;
      for(iteMsg = ite->second.begin(); iteMsg!=ite->second.end(); iteMsg++) {
        std::cout<<"  MSGID:"<<iteMsg->first<<std::endl;
        for(iteSIg = iteMsg->second.begin(); iteSIg!=iteMsg->second.end(); iteSIg++) {
          std::cout<<"    SIGName:"<<iteSIg->first<<std::endl;
        }
      }
    }*/

    /*
    std::map<std::string, std::vector<Message>>::iterator ite;
    for(ite = dbc.messageList.begin(); ite != dbc.messageList.end(); ite++) {
      std::cout<<"*********"<<ite->first<<"********"<<std::endl;
      for(auto msg:ite->second) {
        std::cout << msg.getName() << " " << msg.getId() << std::endl;
        for(auto sig : msg) {
          std::cout << "Signal: " << sig.getName() << "  "<<std::endl;
        }
      }
    }*/
    /*
    for(auto message : dbc) {
        std::cout << message.getName() << " " << message.getId() << std::endl;
        for(auto sig : message) {
            std::cout << "Signal: " << sig.getName() << "  ";
            std::cout << "To: ";
            for (auto to : sig.getTo()) {
                std::cout << to << ", ";
            }
            std::cout << sig.getStartbit() << "," << sig.getLength() << std::endl;
            std::cout << "(" << sig.getFactor() << ", " << sig.getOffset() << ")" << std::endl;
            std::cout << "[" << sig.getMinimum() << "," << sig.getMaximum() << "]" << std::endl;
            if (sig.getMultiplexor() == Multiplexor::MULTIPLEXED) {
                std::cout << "#" << sig.getMultiplexedNumber() << "#" << std::endl;
            } else if (sig.getMultiplexor() == Multiplexor::MULTIPLEXOR) {
                std::cout << "+Multiplexor+" << std::endl;
            }
            std::cout << std::endl;
        };
    }*/

  //step3

  upstreamThread upThreadTh(&dbc);
  upThreadTh.start();
  upThreadTh.join();

} catch (std::invalid_argument& ex) {
  std::cout << ex.what() << std::endl;
}
  //std::this_thread::sleep_for(std::chrono::seconds(2));

//std::cout << "这是主线程" << std::endl;

  return 0;
}
