#include "Thread.hpp"

NThread::NThread()
{
  this->isInterript = false;
}

NThread::~NThread()
{
  if (this->isInterrupted()) {
    this->interrupt();
  }

  if(this->th.joinable()) {
    this->th.join();
  }
}

void NThread::start() {
  std::thread thr(std::bind(&NThread::run, this));
  this->th = std::move(thr);
}

std::thread::id NThread::getId() {
  return this->th.get_id();
}

void NThread::interrupt() {
  this->isInterript = true;
}

bool NThread::isInterrupted() {
  return this->isInterript;
}

void NThread::join() {
  this->th.join();
}

void NThread::run() {

}
