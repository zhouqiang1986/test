#include  "upstreamlcm.hpp"

lcmHandler::lcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

uint64_t lcmHandler::hexToReal(uint8_t tData[]) {

}

void lcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  int32_t pkg_len;
  uint8_t  dataLen;
  uint32_t dataId;
  uint64_t dataData;

  Message msg;
  uint8_t tData[13] = {0,1,1,1,1,1,1,1,1,1,1,1,1};
  /*
  printf("utime:%ld\n", rdata->utime);
  printf("data_length:%d\n", rdata->data_length);
  printf("data[0]:%d\n", rdata->data[0]);
  printf("data[1]:%d\n", rdata->data[1]);
  printf("data[2]:%d\n", rdata->data[2]);
  printf("data[3]:%d\n", rdata->data[3]);
  printf("data[4]:%d\n", rdata->data[4]);
  printf("data[5]:%d\n", rdata->data[5]);
  */
  pkg_len = rdata->data_length;
  for(int i=0; i<pkg_len; i++)
  {

    for(int j=0; j<13; j++) {
      tData[j] = rdata->data[j + i*13];
    }
    dataLen = tData[0];
    dataId = (tData[1]<<24) | (tData[2]<<16) | (tData[3]<<8) | tData[4];
    uint8_t *tmpData = new uint8_t[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = tData[5+k];
    }
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        for(auto tSg : tMsg) {
          uint64_t realValue;
          if(0 == tSg.getByteOrder()) { //bigen
            if(tSg.getStartbit()%8 >= tSg.getLength()) {
              realValue = tmpData[tSg.getStartbit()/8]&(2^(tSg.getStartbit()%8+1) - 2^(tSg.getStartbit()%8+1 - tSg.getLength())));
            } else {
              realValue = tmpData[tSg.getStartbit()/8]&(2^(tSg.getStartbit()%8+1));

            }
          } else {
            if((8-tSg.getStartbit()%8) >= tSg.getLength()) {
              realValue = tmpData[tSg.getStartbit()/8]&(2^(tSg.getLength())-1));
            } else {
              realValue = tmpData[tSg.getStartbit()/8]&(2^8-2^(tSg.getStartbit()%8));

            }
          }
        }
      }
      //std::cout << tMsg.getName() << " " << tMsg.getId() << std::endl;
    }

    printf("dataLen:%d\n", dataLen);
    printf("dataLen:%x\n", dataId);
    printf("dataLen:%x\n", dataData);
    //std::cout << "dataLen:" <<std::hex<< (int)dataLen << std::endl;
    //std::cout << "dataId:" << std::hex<< dataLen << std::endl;
    //std::cout << "dataData:" << std::hex<< dataLen << std::endl;

  }


  lcm.publish("UPSTREAMDBCSED", rdata);
}
