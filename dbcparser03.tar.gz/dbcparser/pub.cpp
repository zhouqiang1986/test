#include <lcm/lcm-cpp.hpp>
#include "lcmtypes/buffer_data_t.hpp"
#include <iostream>
int main(int argc, char ** argv)
{
     lcm::LCM lcm;
     if(!lcm.good())
         return 1;

     lcmtypes::buffer_data_t my_data;
     my_data.utime = 4;
     my_data.data_length = 1;

     my_data.data.resize(8);
     for(int i = 0; i < my_data.data_length; i++)
     {
       // my_data.data[1 + i*13] = 128;
       // my_data.data[2 + i*13] = 123;
       // my_data.data[3 + i*13] = 4;
       // my_data.data[4 + i*13] = 0xa5;
       // my_data.data[5 + i*13] = 0x64;
       my_data.data[1] = 128;
       my_data.data[2] = 123;
       my_data.data[3] = 4;
       my_data.data[4] = 0xa5;
       my_data.data[5] = 0x64;
       for(int x = 0; x<6;x++ )
          std::cout<< (int)my_data.data[x]<< std::endl;
       lcm.publish("UPSTREAMDBCREC", &my_data);
     }



     return 0;
}
