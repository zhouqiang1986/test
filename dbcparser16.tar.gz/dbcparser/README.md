can-dbcparser
=============

Short Project to parse the DBC files used by Vector for CAN

# Compilation

```
mkdir build
cd build
cmake ..
make
```

# Usage

```
 ./candbcparser canmatrix.dbc
 ```
