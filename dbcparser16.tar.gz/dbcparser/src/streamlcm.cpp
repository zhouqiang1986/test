#include  "streamlcm.hpp"
#include "streamthread.hpp"
#include <math.h>
#include <stdio.h>
#include <algorithm>

#include "lcmtypes/camera_info_t.hpp"

lcmHandler::lcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;

  send_mobile_eye_cmd_flag = 0;
  yaw_rate_ifo = 0;
  spe_out_ifo = 0;
}

int64_t lcmHandler::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void lcmHandler::dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue) {
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue>>next_len)<<(tSg.getStartbit()%8+1-head_len);
    if(next_len >= 8) {
      for(int i=0; i<(data_len-head_len)/8; i++) {
        next_len -= 8;
        tData[data_num+i+1] = (hexValue>>next_len)&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= (hexValue&((uint64_t)pow(2,next_len)-1))<<(8-next_len);
    }
  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue&((uint64_t)pow(2,head_len)-1))<<(tSg.getStartbit()%8);
    if(next_len >= 8) {
      for(int j=0; j<(data_len-head_len)/8; j++) {
        next_len -= 8;
        tData[data_num+j+1] = (hexValue>>(head_len+j*8))&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= hexValue>>(data_len-next_len);
    }
  }
}

void lcmHandler::getHexDataBuf(std::vector<Message> dbcList, std::vector<uint8_t>& tBuf_data, uint32_t msgId, std::string str, double mValue) {
  for(auto tMsg : dbcList) {
    if(msgId == tMsg.getId()) {
      tBuf_data.push_back(8);
      tBuf_data.push_back((tMsg.getId()>>24)&0xff);
      tBuf_data.push_back((tMsg.getId()>>16)&0xff);
      tBuf_data.push_back((tMsg.getId()>>8)&0xff);
      tBuf_data.push_back(tMsg.getId()&0xff);
      uint8_t tData[8] = {0};
      for(auto tSg : tMsg) {
        if(tSg.getName() == str) {
          uint64_t hexValue = (mValue-tSg.getOffset())/tSg.getFactor();
          dorConvert(tSg, tData, hexValue);
          break;
        }
      }
      for(int k=0; k<8; k++) {
        tBuf_data.push_back(tData[k]);
      }
      break;
    }
  }
}

void lcmHandler::rsds_pub() {
  while(1) {
    //printf("rsds_pub is running\n");
    usleep(100000);//10Hz

  }
}

void lcmHandler::esrrear_pub() {
  while(1) {
    //printf("esrrear_pub is running\n");
    usleep(100000);//10Hz
  }
}

void lcmHandler::canesrfront_pub() {
  while(1) {
    //printf("canesrfront_pub is running\n");
    usleep(100000);//10Hz
  }
}

void lcmHandler::adcan_pub() {
  while(1) {
    //printf("adcan_pub is running\n");
    usleep(100000);//10Hz
  }
}

void lcmHandler::mobileeyeifo_pub() {

  while(1) {
    //printf("mobileeyeifo_pub is running\n");
    usleep(100000);//10Hz

  }
}

void lcmHandler::mobileeyecon_pub() {
  while(1) {
    //printf("mobileeyecon_pub is running\n");
    usleep(100000);//10Hz
  }
}

void lcmHandler::tocamera_pub() {
  lcmtypes::buffer_data_t buffer_data;
  std::string sensor = "Sensor_CAN_MOBILE_RX";
  msgIte_t msgIte;
  std::vector<Message> dbcList;
  std::vector<uint8_t> tBuf_data;
  uint8_t count = 0;
  send_mobile_eye_cmd_flag = 1;
  while(1) {
    printf("tocamera_pub is running\n");
    usleep(50000);//20Hz
    if(send_mobile_eye_cmd_flag) {
      msgIte = pdbc_lcm->messageList.find(sensor);
      if(msgIte != pdbc_lcm->messageList.end()) {
        dbcList = msgIte->second;
        getHexDataBuf(dbcList, tBuf_data, 0x330, "msg330_RC", count);
        getHexDataBuf(dbcList, tBuf_data, 0x330, "YawRt_raw", yaw_rate_ifo);
        getHexDataBuf(dbcList, tBuf_data, 0x330, "IMULonAccPriAval", 1);
        getHexDataBuf(dbcList, tBuf_data, 0x330, "IMULonAccSecAval", 1);
        getHexDataBuf(dbcList, tBuf_data, 0x330, "msg330_CS", 0);

        getHexDataBuf(dbcList, tBuf_data, 0x340, "msg340_RC", count);
        getHexDataBuf(dbcList, tBuf_data, 0x340, "VARIABLE_1", 1);
        getHexDataBuf(dbcList, tBuf_data, 0x340, "VARIABLE_2", 3);
        getHexDataBuf(dbcList, tBuf_data, 0x340, "YawRt_raw", abs(yaw_rate_ifo));
        getHexDataBuf(dbcList, tBuf_data, 0x340, "VARIABLE_3", 1);
        getHexDataBuf(dbcList, tBuf_data, 0x340, "msg340_CS", 0);

        getHexDataBuf(dbcList, tBuf_data, 0x3E9, "VehSpdAvgDrvn_PB_raw", spe_out_ifo);
        getHexDataBuf(dbcList, tBuf_data, 0x3E9, "VehSpdAvgDrvn_PB_raw2", spe_out_ifo);
        uint16_t checksum;
        std::cout<<"tBuf_data.size():"<<tBuf_data.size()<<std::endl;
        /*
        int i;
        for(i=0; i<tBuf_data.size()-1; i++) {
          checksum = (tBuf_data[i*13+5]+tBuf_data[i*13+6]+tBuf_data[i*13+7]+tBuf_data[i*13+8]+tBuf_data[i*13+9]+tBuf_data[i*13+10])+tBuf_data[i*13+11]&0xF8+(((tBuf_data[i*13+1]<<24)+(tBuf_data[i*13+2]<<16)+(tBuf_data[i*13+3]<<8)+tBuf_data[i*13+4])>>3);
          tBuf_data[i*13+11] |= (checksum>>8)&0x3;
          tBuf_data[i*13+12] = checksum&0xFF;
        }*/
        buffer_data.data.clear();
        buffer_data.data.insert(buffer_data.data.end(), tBuf_data.begin(), tBuf_data.end());
        tBuf_data.clear();
        buffer_data.utime = getCurrentTime();
        buffer_data.data_length = buffer_data.data.size();
        lcm.publish("TO_CAMERA", &buffer_data);
        count = count<3 ? count+1 : 0;
      }
    }
  }
}

void lcmHandler::upstream_pub() {
  while(1) {
    //printf("upstreampub is running\n");
    usleep(100000);//10Hz
    /*
    up_mutex[0].lock();
    buffer_dbc.utime = getCurrentTime();
    buffer_dbc.data_length = buffer_dbc.data.size();
    lcm.publish("UPSTREAMDBCSED", &buffer_dbc);
    buffer_dbc.data.clear();
    buffer_dbc.data_length = buffer_dbc.data.size();
    up_mutex[0].unlock();*/
  }
}

uint64_t lcmHandler::doConvert(Signal tSg, uint8_t tmpData[]) {
  uint64_t realValue;
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    uint64_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
    realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
    if(next_len > 0) {
      for(int m=0; m<(data_len-head_len)/8; m++) {
        next_len -= 8;
        realValue |= (tmpData[data_num+m+1]<<next_len);
      }
      realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
    } else {
      realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
    }

  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  head_len;
    uint64_t lShiftS = pow(2,head_len);

    realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);

    if((data_len-next_len) >= 8) {

      for(int n=0; n<(data_len-head_len)/8; n++) {
        realValue |= tmpData[data_num+n+1]<<next_len;
        next_len += 8;
      }
    }

    if((data_len-next_len) > 0) {
      realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;

    }
  }

  return realValue;
}



void lcmHandler::rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                       const std::string& chan,
                       const lcmtypes::buffer_data_t *msg)
{

}

void lcmHandler::esrrearHandleMessage(const lcm::ReceiveBuffer *buf,
                          const std::string& chan,
                          const lcmtypes::buffer_data_t *msg)
{

}

void lcmHandler::canesrfrontHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void lcmHandler::adcanHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void lcmHandler::mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *rdata)
{
  //printf("Received message on channel \"%s\":\n", chan.c_str());
  std::map<uint32_t, std::map<std::string, double>> k_v;
  std::string sensor;
  cfgListIte_t cfgIte = pdbc_lcm->cfgList->begin();
  while(cfgIte != pdbc_lcm->cfgList->end()) {

    if(cfgIte->second.find("lcm_channel") != cfgIte->second.end()) {
      if(cfgIte->second.find("lcm_channel")->second.compare(chan) == 0) {
        sensor = cfgIte->first;
        dbcDict.insert(std::make_pair(cfgIte->first, k_v));
      }
    }
    cfgIte++;
  }

  std::vector<Message> dbcList = pdbc_lcm->messageList.find(sensor)->second;
  std::map<uint32_t, std::map<std::string, double>>& msgList = dbcDict.find(sensor)->second;
  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }
    for(auto tMsg : dbcList) {
      if(dataId == tMsg.getId()) {
        double rValue;
        std::map<std::string, double> sIg;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sIg[tSg.getName()] = rValue;
        }
        msgList[dataId] = sIg;
      }
    }
  }

  if(sensor == "Sensor_CAN_MOBILE_TX") {
    lcmtypes::camera_info_t camera_info;
    camera_info.utime = getCurrentTime();
    std::map<std::string, double> msg_6A4 = msgList[0x6A4];
    camera_info.lines[1].type = msg_6A4["VIS_LANE_LEFT_PARALL_TYPE"];
    camera_info.lines[2].type = msg_6A4["VIS_LANE_RIGHT_PARALL_TYPE"];
    if(msg_6A4["VIS_LANE_LANE_CHANGE"] == 1) {
      camera_info.change_lane = 1;
    } else {
      camera_info.change_lane = 0;
    }

    std::map<std::string, double> msg_6A5 = msgList[0x6A5];
    camera_info.center_line.a = msg_6A5["VIS_CENTER_POLYNOMIAL_A0"];
    camera_info.center_line.b = msg_6A5["VIS_CENTER_POLYNOMIAL_A1"];
    camera_info.center_line.c = msg_6A5["VIS_CENTER_POLYNOMIAL_A2"];
    camera_info.center_line.d = msg_6A5["VIS_CENTER_POLYNOMIAL_A3"];
    camera_info.lane_width = msg_6A5["VIS_CENTER_POLYNOMIAL_WIDTH"];
    std::map<std::string, double> msg_6A9 = msgList[0x6A9];
    camera_info.lines[0].a = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A0"];
    camera_info.lines[0].b = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A1"];
    camera_info.lines[0].c = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A2"];
    camera_info.lines[0].d = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A3"];
    camera_info.lines[0].length = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_RANGE"];
    std::map<std::string, double> msg_6A7 = msgList[0x6A7];
    camera_info.lines[1].a = msg_6A7["VIS_LANE_LEFT_PARALL_A0"];
    camera_info.lines[1].b = msg_6A7["VIS_LANE_LEFT_PARALL_A1"];
    camera_info.lines[1].c = msg_6A7["VIS_LANE_LEFT_PARALL_A2"];
    camera_info.lines[1].d = msg_6A7["VIS_LANE_LEFT_PARALL_A3"];
    camera_info.lines[1].length = msg_6A7["VIS_LANE_LEFT_PARALL_RANGE"];
    std::map<std::string, double> msg_6A6 = msgList[0x6A6];
    camera_info.lines[2].a = msg_6A6["VIS_LANE_RIGHT_PARALL_A0"];
    camera_info.lines[2].b = msg_6A6["VIS_LANE_RIGHT_PARALL_A1"];
    camera_info.lines[2].c = msg_6A6["VIS_LANE_RIGHT_PARALL_A2"];
    camera_info.lines[2].d = msg_6A6["VIS_LANE_RIGHT_PARALL_A3"];
    camera_info.lines[2].length = msg_6A6["VIS_LANE_RIGHT_PARALL_RANGE"];
    std::map<std::string, double> msg_6A8 = msgList[0x6A8];
    camera_info.lines[3].a = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A0"];
    camera_info.lines[3].b = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A1"];
    camera_info.lines[3].c = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A2"];
    camera_info.lines[3].d = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A3"];
    camera_info.lines[3].length = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_RANGE"];

    camera_info.object_count = 15;
    camera_info.objects.resize(camera_info.object_count);
    std::map<std::string, double> msg_677 = msgList[0x677];
    std::string id_label[camera_info.object_count];
    char tCHAR[2];
    int j;
    for(j=0; j<camera_info.object_count; j++) {
      sprintf(tCHAR, "%02i", j+1);
      id_label[j] = tCHAR;
      //std::cout<<id_label[j]<<std::endl;
    }
    j=0;
    for(auto obj : camera_info.objects) {
      obj.width = msg_677["VIS_OBS_WIDTH_01"+id_label[j]];
      obj.centerPoint.y = msg_677["VIS_OBS_LONG_POS_"+id_label[j]];
      obj.centerPoint.x = msg_677["VIS_OBS_LAT_POS_"+id_label[j]];
      obj.speedLat = msg_677["VIS_OBS_LAT_VEL_"+id_label[j]];
      obj.speedLon = msg_677["VIS_OBS_LONG_VEL_"+id_label[j]];
      j++;
    }

    camera_info.center_line.length = std::max(camera_info.lines[1].length, camera_info.lines[2].length);

    if(!lcm.good())
    {
      return ;
    }
    lcm.publish("camera", &camera_info);
  }
}

void lcmHandler::mobileeyeconHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void lcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{/*
  std::vector< lcmtypes::buffer_message_t > tBuffer_dbc;
  lcmtypes::buffer_message_t buffer_message;

  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }

    buffer_message.sigMap.clear();

    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        buffer_message.id = dataId;
        double rValue;
        lcmtypes::map_data_t sigMap;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sigMap.sigName = tSg.getName();
          sigMap.sigValue = rValue;
          buffer_message.sigMap.push_back(sigMap);
        }
        buffer_message.sigCnt = buffer_message.sigMap.size();
        tBuffer_dbc.push_back(buffer_message);
      }

    }

  }

  up_mutex[0].lock();
  buffer_dbc.data.clear();
  buffer_dbc.data.insert(buffer_dbc.data.begin(), tBuffer_dbc.begin(), tBuffer_dbc.end());
  up_mutex[0].unlock(); */

}
