/*
 * dbctree.hpp
 *
 *  Created on: 04.10.2013
 *      Author: downtimes
 */

#ifndef DBCTREE_HPP_
#define DBCTREE_HPP_

#include <vector>
#include <iosfwd>
#include <map>

#include "message.hpp"

/**
 * This is the Top class of the dbclib and the interface to the user.
 * It enables its user to iterate over the Messages of a DBC-File
 */

class DBCIterator {

	typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;


	typedef std::vector<std::string> files_t;
	files_t fileList;

	typedef std::map<std::string, std::vector<Message>> messages_t;
	//typedef std::vector<Message> messages_t;
	//This list contains all the messages which got parsed from the DBC-File
public:
	cfgList_t *cfgList;
	messages_t messageList;

public:
	typedef messages_t::const_iterator const_iterator;

	//Constructors taking either a File or a Stream of a DBC-File
	explicit DBCIterator() {};
	explicit DBCIterator(cfgList_t *cfgList);
	//explicit DBCIterator(std::istream& stream);

	/*
	 * Functionality to access the Messages parsed from the File
	 * either via the iterators provided by begin() and end() or by
	 * random access operator[]
	 */
	const_iterator begin() const { return messageList.begin(); }
	const_iterator end() const { return messageList.end(); }
	//messages_t::const_reference operator[](std::size_t elem) const {
	//	return messageList[elem];
	//}
	messages_t& operator[](std::string elem) {
		return messageList;
	}

private:
	void init(std::istream& stream, std::string& str);
	void getFiles(const std::string& filePath);

public:
	
};




#endif /* DBCTREE_HPP_ */
