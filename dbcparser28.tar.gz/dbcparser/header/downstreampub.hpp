#ifndef DOWNSTREAMPUB_HPP_
#define DOWNSTREAMPUB_HPP_

#include <lcm/lcm-cpp.hpp>
#include <mutex>

#include "Thread.hpp"
#include "lcmtypes/buffer_data_t.hpp"

class downstreampub : public NThread {

public:
  downstreampub(lcmtypes::buffer_data_t *buffer_data, std::mutex *down_mutex);
  virtual ~downstreampub();

  virtual void run() override;

private:
  lcm::LCM lcm;
  lcmtypes::buffer_data_t *buffer_data;
  std::mutex *down_mutex;

private:
  int64_t getCurrentTime();

};

#endif
