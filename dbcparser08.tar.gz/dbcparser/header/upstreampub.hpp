#ifndef UPSTREAMPUB_HPP_
#define UPSTREAMPUB_HPP_

#include <lcm/lcm-cpp.hpp>
#include <mutex>

#include "Thread.hpp"
#include "lcmtypes/wey_data_t.hpp"

class upstreampub : public NThread {

public:
  upstreampub(lcmtypes::wey_data_t *wey_data_t, std::mutex *up_mutex);
  virtual ~upstreampub();

  virtual void run() override;

private:
  lcm::LCM lcm;
  lcmtypes::wey_data_t *wey_data;
  std::mutex *up_mutex;

private:
  int64_t getCurrentTime();

};

#endif
