#ifndef DOWNSTREAMLCM_HPP_
#define DOWNSTREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>
#include <mutex>

#include "dbciterator.hpp"
#include "lcmtypes/wey_data_t.hpp"
#include "lcmtypes/buffer_data_t.hpp"

class downlcmHandler {
public:
  downlcmHandler() {};
  downlcmHandler(DBCIterator *pdbc, std::mutex *down_mutex);
  ~downlcmHandler() {};
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::wey_data_t *msg);
public:
  lcmtypes::buffer_data_t buffer_data;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  std::mutex *down_mutex;

private:
  void dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue);
};

#endif
