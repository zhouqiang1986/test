#ifndef UPSTREAMTHREAD_HPP_
#define UPSTREAMTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>

#include "Thread.hpp"
#include "dbciterator.hpp"
#include <mutex>

class upThread : public NThread {

public:
  upThread() {};
  upThread(DBCIterator *pdbc);
  virtual ~upThread();

  virtual void run() override;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  std::mutex up_mutex;

};

#endif
