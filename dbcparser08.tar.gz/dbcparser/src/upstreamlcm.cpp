#include  "upstreamlcm.hpp"
#include "signal.hpp"
#include "lcmtypes/futian_message_t.hpp"
#include "upstreamthread.hpp"

#include <math.h>

uplcmHandler::uplcmHandler(DBCIterator *pdbc, std::mutex *up_mutex) {
  pdbc_lcm = pdbc;
  this->up_mutex = up_mutex;
}

uint64_t uplcmHandler::doConvert(Signal tSg, uint8_t tmpData[]) {
  uint64_t realValue;
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    uint64_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
    realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
    if(next_len > 0) {
      for(int m=0; m<(data_len-head_len)/8; m++) {
        next_len -= 8;
        realValue |= (tmpData[data_num+m+1]<<next_len);
      }
      realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
    } else {
      realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
    }

  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  head_len;
    uint64_t lShiftS = pow(2,head_len);
    //printf(" data_len = %d\n", data_len);
    //printf(" head_len = %d\n", head_len);
    //printf(" data_num = %d\n", data_num);
    //printf(" next_len = %d\n", next_len);
    realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);
    //printf(" realValue = %ld\n", realValue);
    if((data_len-next_len) >= 8) {
      //printf(" (data_len-next_len) >= 8\n");
      for(int n=0; n<(data_len-head_len)/8; n++) {
        realValue |= tmpData[data_num+n+1]<<next_len;
        next_len += 8;
      }
    }
    //printf(" realValue = %ld\n", realValue);
    if((data_len-next_len) > 0) {
      realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;
      //printf(" realValue = %ld\n", realValue);
    }
  }

  return realValue;
}

void uplcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  lcmtypes::futian_message_t futian_message;

  int32_t pkg_len;
  int32_t pkgNum;
  uint8_t  dataLen;
  uint32_t dataId;
  uint64_t dataData;

  uint8_t *tData = new uint8_t[13];

  pkg_len = rdata->data_length/13;
  //
  for(int i=0; i<pkg_len; i++)
  {
    for(int j=0; j<13; j++) {
      tData[j] = rdata->data[j + i*13];
    }
    dataLen = tData[0];
    dataId = (tData[1]<<24) | (tData[2]<<16) | (tData[3]<<8) | tData[4];
    //printf("dataLen:%d\n", dataLen);
    //printf("dataId:%d\n", dataId);
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = tData[5+k];
    }
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        for(auto tSg : tMsg) {
          double rValue;
          /*
          if(Sign::UNSIGNED == tSg.getSign()) {
            rValue = realValue*tSg.getFactor() + tSg.getOffset();
            printf(" rValue = %lf\n", rValue);
          } else { */
            rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();

          //}
          //std::cout << "SG_Name: " << tSg.getName() <<std::endl;
          //printf(" Value = %lf\n", rValue);
          std::string sgName = tSg.getName();

          switch (dataId) {
            case  0x200:
              if(0 == sgName.compare("ExtlAccelerationDemand")) {
                futian_message.ExtlAccelerationDemand = rValue;
              }
              break;
            case  0xE1:
              if(0 == sgName.compare("ControlMode")) {
                futian_message.ControlMode = rValue;
              } else if(0 == sgName.compare("GearControl")) {
                futian_message.GearControl = rValue;
              } else if(0 == sgName.compare("Accelerator_enable")) {
                futian_message.Accelerator_enable = rValue;
              } else if(0 == sgName.compare("AcceleratorControl")) {
                futian_message.AcceleratorControl = rValue;
              } else if(0 == sgName.compare("SteeringAngleControl")) {
                futian_message.SteeringAngleControl = rValue;
              } else if(0 == sgName.compare("Steering_enable")) {
                futian_message.Steering_enable = rValue;
              } else if(0 == sgName.compare("ParkingBrakeControl")) {
                futian_message.ParkingBrakeControl = rValue;
              } else if(0 == sgName.compare("SteeringTorqueControl")) {
                futian_message.SteeringTorqueControl = rValue;
              } else if(0 == sgName.compare("SetBrakelightST")) {
                futian_message.SetBrakelightST = rValue;
              } else if(0 == sgName.compare("SetTurnrightST")) {
                futian_message.SetTurnrightST = rValue;
              } else if(0 == sgName.compare("SetTurnleftST")) {
                futian_message.SetTurnleftST = rValue;
              } else if(0 == sgName.compare("SetHazardLight")) {
                futian_message.SetHazardLight = rValue;
              } else if(0 == sgName.compare("SetLowBeamSt")) {
                futian_message.SetLowBeamSt = rValue;
              } else if(0 == sgName.compare("SetHighBeamSt")) {
                futian_message.SetHighBeamSt = rValue;
              }
              break;
            case  0x215:
              if(0 == sgName.compare("SteeringWheelSpeedControl")) {
                futian_message.SteeringWheelSpeedControl = rValue;
              }
              break;
            case  0x226:
              if(0 == sgName.compare("AutoDrive_Enable")) {
                futian_message.AutoDrive_Enable = rValue;
              }
              break;
            case  0x2AB:
              if(0 == sgName.compare("EHB_Brake_Pedal_Position")) {
                futian_message.EHB_Brake_Pedal_Position = rValue;
              }
              break;
            case  0x311:
              if(0 == sgName.compare("ABS_ESP_FRWhSpeedValidData")) {
                futian_message.ABS_ESP_FRWhSpeedValidData = rValue;
              } else if(0 == sgName.compare("ABS_ESP_FLWhSpeedValidData")) {
                futian_message.ABS_ESP_FLWhSpeedValidData = rValue;
              } else if(0 == sgName.compare("ABS_ESP_FLWhSpeed")) {
                futian_message.ABS_ESP_FLWhSpeed = rValue;
              } else if(0 == sgName.compare("ABS_ESP_ABS_Fault")) {
                futian_message.ABS_ESP_ABS_Fault = rValue;
              } else if(0 == sgName.compare("ABS_ESP_FRWhSpeed")) {
                futian_message.ABS_ESP_FRWhSpeed = rValue;
              }
              break;
            case  0x2EA:
              if(0 == sgName.compare("ABS_ESP_RRWhSpeedValidData")) {
                futian_message.ABS_ESP_RRWhSpeedValidData = rValue;
              } else if(0 == sgName.compare("ABS_ESP_RLWhSpeedValidData")) {
                futian_message.ABS_ESP_RLWhSpeedValidData = rValue;
              } else if(0 == sgName.compare("ABS_ESP_RLWhSpeed")) {
                futian_message.ABS_ESP_RLWhSpeed = rValue;
              } else if(0 == sgName.compare("ABS_ESP_RRWhSpeed")) {
                futian_message.ABS_ESP_RRWhSpeed = rValue;
              } else if(0 == sgName.compare("ABS_ESP_WssRLEdgesSum")) {
                futian_message.ABS_ESP_WssRLEdgesSum = rValue;
              } else if(0 == sgName.compare("ABS_ESP_WssRREdgesSum")) {
                futian_message.ABS_ESP_WssRREdgesSum = rValue;
              }
              break;
            case  0x213:
              if(0 == sgName.compare("LongitudeACC")) {
                futian_message.LongitudeACC = rValue;
              } else if(0 == sgName.compare("VehDynYawRate")) {
                futian_message.VehDynYawRate = rValue;
              }
              break;
            case  0x2D2:
              if(0 == sgName.compare("ABS_ESP_WssFLEdgesSum")) {
                futian_message.ABS_ESP_WssFLEdgesSum = rValue;
              } else if(0 == sgName.compare("ABS_ESP_WssFREdgesSum")) {
                futian_message.ABS_ESP_WssFREdgesSum = rValue;
              }
              break;
            case  0x361:
              if(0 == sgName.compare("VBUS_VCU1_N_APS_PER")) {
                futian_message.VBUS_VCU1_N_APS_PER = rValue;
              }
              break;
            case  0x520:
              if(0 == sgName.compare("VBUS_VCU4_N_VehicleSpeed")) {
                futian_message.VBUS_VCU4_N_VehicleSpeed = rValue;
              } else if(0 == sgName.compare("VBUS_VCU4_St_Gears")) {
                futian_message.VBUS_VCU4_St_Gears = rValue;
              } else if(0 == sgName.compare("VBUS_VCU4_BRAKE_STA")) {
                futian_message.VBUS_VCU4_BRAKE_STA = rValue;
              }
              break;
            case  0x511:
              if(0 == sgName.compare("EHPS_SteeringTorque")) {
                futian_message.EHPS_SteeringTorque = rValue;
              } else if(0 == sgName.compare("EHPS_WarningLamp")) {
                futian_message.EHPS_WarningLamp = rValue;
              } else if(0 == sgName.compare("EHPS_ManualInterventionST")) {
                futian_message.EHPS_ManualInterventionST = rValue;
              } else if(0 == sgName.compare("EPS_DrivingMode")) {
                futian_message.EPS_DrivingMode = rValue;
              } else if(0 == sgName.compare("EHPS_AvailSts")) {
                futian_message.EHPS_AvailSts = rValue;
              } else if(0 == sgName.compare("EHPS_SteeringAngle")) {
                futian_message.EHPS_SteeringAngle = rValue;
              } else if(0 == sgName.compare("SteeringWheelSpeed")) {
                futian_message.SteeringWheelSpeed = rValue;
              }
              break;
            case  0x314:
              if(0 == sgName.compare("LOW_BeamST")) {
                futian_message.LOW_BeamST = rValue;
              } else if(0 == sgName.compare("BrakelightST")) {
                futian_message.BrakelightST = rValue;
              } else if(0 == sgName.compare("TurnrightST")) {
                futian_message.TurnrightST = rValue;
              } else if(0 == sgName.compare("TurnleftST")) {
                futian_message.TurnleftST = rValue;
              } else if(0 == sgName.compare("HighbeamST")) {
                futian_message.HighbeamST = rValue;
              } else if(0 == sgName.compare("HazardEnvironmentLight")) {
                futian_message.HazardEnvironmentLight = rValue;
              }
              break;
            case  0x431:
              if(0 == sgName.compare("ICParkBrake")) {
                futian_message.ICParkBrake = rValue;
              }
              break;
            case  0x320:
              if(0 == sgName.compare("EPB_Warning_State")) {
                futian_message.EPB_Warning_State = rValue;
              } else if(0 == sgName.compare("EPB_DriveMode")) {
                futian_message.EPB_DriveMode = rValue;
              }
              break;
            case  0x207:
              if(0 == sgName.compare("EHB_Condition")) {
                futian_message.EHB_Condition = rValue;
              } else if(0 == sgName.compare("EHB_SDC_ParkReq")) {
                futian_message.EHB_SDC_ParkReq = rValue;
              } else if(0 == sgName.compare("EHB_Flt")) {
                futian_message.EHB_Flt = rValue;
              } else if(0 == sgName.compare("Dbrk_Act_Mpa")) {
                futian_message.Dbrk_Act_Mpa = rValue;
              } else if(0 == sgName.compare("BrkPedal_Act")) {
                futian_message.BrkPedal_Act = rValue;
              } else if(0 == sgName.compare("Control_By_Wire_Flag")) {
                futian_message.Control_By_Wire_Flag = rValue;
              }
              break;
            case  0x206:
              if(0 == sgName.compare("Brake_CMD_EN")) {
                futian_message.Brake_CMD_EN = rValue;
              } else if(0 == sgName.compare("Brake_CMD")) {
                futian_message.Brake_CMD = rValue;
              }
              break;
          }

        }

      }

    }

  }
  up_mutex->lock();
  wey_data.data.clear();
  wey_data.data.push_back(futian_message);
  up_mutex->unlock();
}
