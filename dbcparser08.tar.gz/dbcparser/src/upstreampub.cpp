#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "upstreampub.hpp"

upstreampub::upstreampub(lcmtypes::wey_data_t *wey_data, std::mutex *up_mutex) {
  this->wey_data = wey_data;
  this->up_mutex = up_mutex;
}

upstreampub::~upstreampub() {

}

int64_t upstreampub::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void upstreampub::run() {
  if(!lcm.good())
  {
    return ;
  }

  while(!this->isInterrupted())
  {
    printf("upstreampub is running\n");
    sleep(6);
    up_mutex->lock();
    wey_data->utime = getCurrentTime();
    wey_data->data_length = wey_data->data.size();
    lcm.publish("UPSTREAMDBCSED", wey_data);
    wey_data->data.clear();
    wey_data->data_length = wey_data->data.size();
    up_mutex->unlock();
  }
}
