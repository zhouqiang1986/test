#include  "downstreamlcm.hpp"
#include "signal.hpp"


#include <math.h>

downlcmHandler::downlcmHandler(DBCIterator *pdbc, std::mutex *down_mutex) {
  pdbc_lcm = pdbc;
  this->down_mutex = down_mutex;
}

void downlcmHandler::dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue) {
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue>>next_len)<<(tSg.getStartbit()%8+1-head_len);
    if(next_len >= 8) {
      for(int i=0; i<(data_len-head_len)/8; i++) {
        next_len -= 8;
        tData[data_num+i+1] = (hexValue>>next_len)&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= (hexValue&((uint64_t)pow(2,next_len)-1))<<(8-next_len);
    }
  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue&((uint64_t)pow(2,head_len)-1))<<(tSg.getStartbit()%8);
    if(next_len >= 8) {
      for(int j=0; j<(data_len-head_len)/8; j++) {
        next_len -= 8;
        tData[data_num+j+1] = (hexValue>>(head_len+j*8))&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= hexValue>>(data_len-next_len);
    }
  }
}

void downlcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::wey_data_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  int32_t pkg_len = rdata->data_length;
  //printf(" LateralAcce = %lf\n", LateralAcce);
  //printf(" LongitudeAcc = %lf\n", LongitudeAcc);
  //for(int i=0; i<pkg_len; i++){
      std::vector<uint8_t> tBuf_data;
      for(auto tMsg : *pdbc_lcm) {
        switch (tMsg.getId()) {
          case 0x200:
            uint8_t tData1[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("ExtlAccelerationDemand")) {
                hexValue = (rdata->data[pkg_len-1].ExtlAccelerationDemand-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0xE1:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("ControlMode")) {
                hexValue = (rdata->data[pkg_len-1].ControlMode-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("GearControl")) {
                hexValue = (rdata->data[pkg_len-1].GearControl-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("Accelerator_enable")) {
                hexValue = (rdata->data[pkg_len-1].Accelerator_enable-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("AcceleratorControl")) {
                hexValue = (rdata->data[pkg_len-1].AcceleratorControl-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SteeringAngleControl")) {
                hexValue = (rdata->data[pkg_len-1].SteeringAngleControl-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("Steering_enable")) {
                hexValue = (rdata->data[pkg_len-1].Steering_enable-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ParkingBrakeControl")) {
                hexValue = (rdata->data[pkg_len-1].ParkingBrakeControl-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SteeringTorqueControl")) {
                hexValue = (rdata->data[pkg_len-1].SteeringTorqueControl-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SetBrakelightST")) {
                hexValue = (rdata->data[pkg_len-1].SetBrakelightST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SetTurnrightST")) {
                hexValue = (rdata->data[pkg_len-1].SetTurnrightST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SetTurnleftST")) {
                hexValue = (rdata->data[pkg_len-1].SetTurnleftST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SetHazardLight")) {
                hexValue = (rdata->data[pkg_len-1].SetHazardLight-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SetLowBeamSt")) {
                hexValue = (rdata->data[pkg_len-1].SetLowBeamSt-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SetHighBeamSt")) {
                hexValue = (rdata->data[pkg_len-1].SetHighBeamSt-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x215:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("SteeringWheelSpeedControl")) {
                hexValue = (rdata->data[pkg_len-1].SteeringWheelSpeedControl-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x226:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("AutoDrive_Enable")) {
                hexValue = (rdata->data[pkg_len-1].AutoDrive_Enable-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x2AB:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("EHB_Brake_Pedal_Position")) {
                hexValue = (rdata->data[pkg_len-1].EHB_Brake_Pedal_Position-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x311:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("ABS_ESP_FRWhSpeedValidData")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_FRWhSpeedValidData-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_FLWhSpeedValidData")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_FLWhSpeedValidData-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_FLWhSpeed")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_FLWhSpeed-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_ABS_Fault")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_ABS_Fault-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_FRWhSpeed")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_FRWhSpeed-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x2EA:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("ABS_ESP_RRWhSpeedValidData")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_RRWhSpeedValidData-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_RLWhSpeedValidData")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_RLWhSpeedValidData-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_RLWhSpeed")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_RLWhSpeed-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_RRWhSpeed")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_RRWhSpeed-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_WssRLEdgesSum")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_WssRLEdgesSum-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_WssRREdgesSum")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_WssRREdgesSum-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x213:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("LongitudeACC")) {
                hexValue = (rdata->data[pkg_len-1].LongitudeACC-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("VehDynYawRate")) {
                hexValue = (rdata->data[pkg_len-1].VehDynYawRate-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x2D2:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("ABS_ESP_WssFLEdgesSum")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_WssFLEdgesSum-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("ABS_ESP_WssFREdgesSum")) {
                hexValue = (rdata->data[pkg_len-1].ABS_ESP_WssFREdgesSum-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x361:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("VBUS_VCU1_N_APS_PER")) {
                hexValue = (rdata->data[pkg_len-1].VBUS_VCU1_N_APS_PER-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x520:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("VBUS_VCU4_N_VehicleSpeed")) {
                hexValue = (rdata->data[pkg_len-1].VBUS_VCU4_N_VehicleSpeed-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("VBUS_VCU4_St_Gears")) {
                hexValue = (rdata->data[pkg_len-1].VBUS_VCU4_St_Gears-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("VBUS_VCU4_BRAKE_STA")) {
                hexValue = (rdata->data[pkg_len-1].VBUS_VCU4_BRAKE_STA-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x511:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("EHPS_SteeringTorque")) {
                hexValue = (rdata->data[pkg_len-1].EHPS_SteeringTorque-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EHPS_WarningLamp")) {
                hexValue = (rdata->data[pkg_len-1].EHPS_WarningLamp-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EHPS_ManualInterventionST")) {
                hexValue = (rdata->data[pkg_len-1].EHPS_ManualInterventionST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EPS_DrivingMode")) {
                hexValue = (rdata->data[pkg_len-1].EPS_DrivingMode-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EHPS_AvailSts")) {
                hexValue = (rdata->data[pkg_len-1].EHPS_AvailSts-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EHPS_SteeringAngle")) {
                hexValue = (rdata->data[pkg_len-1].EHPS_SteeringAngle-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("SteeringWheelSpeed")) {
                hexValue = (rdata->data[pkg_len-1].SteeringWheelSpeed-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x314:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("LOW_BeamST")) {
                hexValue = (rdata->data[pkg_len-1].LOW_BeamST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("BrakelightST")) {
                hexValue = (rdata->data[pkg_len-1].BrakelightST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("TurnrightST")) {
                hexValue = (rdata->data[pkg_len-1].TurnrightST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("TurnleftST")) {
                hexValue = (rdata->data[pkg_len-1].TurnleftST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("HighbeamST")) {
                hexValue = (rdata->data[pkg_len-1].HighbeamST-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("HazardEnvironmentLight")) {
                hexValue = (rdata->data[pkg_len-1].HazardEnvironmentLight-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x431:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("ICParkBrake")) {
                hexValue = (rdata->data[pkg_len-1].ICParkBrake-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x320:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("EPB_Warning_State")) {
                hexValue = (rdata->data[pkg_len-1].EPB_Warning_State-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EPB_DriveMode")) {
                hexValue = (rdata->data[pkg_len-1].EPB_DriveMode-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x207:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("EHB_Condition")) {
                hexValue = (rdata->data[pkg_len-1].EHB_Condition-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EHB_SDC_ParkReq")) {
                hexValue = (rdata->data[pkg_len-1].EHB_SDC_ParkReq-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EHB_Flt")) {
                hexValue = (rdata->data[pkg_len-1].EHB_Flt-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("Dbrk_Act_Mpa")) {
                hexValue = (rdata->data[pkg_len-1].Dbrk_Act_Mpa-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("BrkPedal_Act")) {
                hexValue = (rdata->data[pkg_len-1].BrkPedal_Act-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("Control_By_Wire_Flag")) {
                hexValue = (rdata->data[pkg_len-1].Control_By_Wire_Flag-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("EPB_DriveMode")) {
                hexValue = (rdata->data[pkg_len-1].EPB_DriveMode-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
          case 0x206:
            uint8_t tData[8] = {0};
            for(auto tSg : tMsg) {
              std::string sgName = tSg.getName();
              uint64_t hexValue;
              if(0 == sgName.compare("Brake_CMD_EN")) {
                hexValue = (rdata->data[pkg_len-1].Brake_CMD_EN-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              } else if(0 == sgName.compare("Brake_CMD")) {
                hexValue = (rdata->data[pkg_len-1].Brake_CMD-tSg.getOffset())/tSg.getFactor();
                dorConvert(tSg, tData, hexValue);
              }
            }
            tBuf_data.push_back(8);
            tBuf_data.push_back((tMsg.getId()>>24)&0xff);
            tBuf_data.push_back((tMsg.getId()>>16)&0xff);
            tBuf_data.push_back((tMsg.getId()>>8)&0xff);
            tBuf_data.push_back(tMsg.getId()&0xff);
            for(int k=0; k<8; k++) {
              tBuf_data.push_back(tData[k]);
            }
          break;
        }

      }
      down_mutex->lock();
      buffer_data.data.clear();
      buffer_data.data.insert(buffer_data.data.end(), tBuf_data.begin(), tBuf_data.end());
      down_mutex->unlock();
  //}

}
