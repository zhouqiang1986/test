#ifndef LongitudeAcc_HPP_
#define LongitudeAcc_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>

#include "dbciterator.hpp"
#include "lcmtypes/LongitudeAcc_t.hpp"

class LongitudeAccHandler {
public:
  LongitudeAccHandler() {};
  LongitudeAccHandler(DBCIterator *pdbc);
  ~LongitudeAccHandler() {};
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::LongitudeAcc_t *msg);

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  uint32_t dataId;
};

#endif
