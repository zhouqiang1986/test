#include  "LongitudeAcc.hpp"
#include "signal.hpp"
#include <math.h>

LongitudeAccHandler::LongitudeAccHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
  dataId = 581;
}

void LongitudeAccHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::LongitudeAcc_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  int32_t pkg_len;
  uint8_t  dataLen;
  uint32_t dataId;

  Message msg;
  uint8_t *tData = new uint8_t[13];

  pkg_len = rdata->data_length/13;
  for(int i=0; i<pkg_len; i++)
  {

    for(int j=0; j<13; j++) {
      tData[j] = rdata->data[j + i*13];
    }
    dataLen = tData[0];
    dataId = (tData[1]<<24) | (tData[2]<<16) | (tData[3]<<8) | tData[4];
    printf("dataLen:%d\n", dataLen);
    printf("dataId:%d\n", dataId);
    uint8_t *tmpData = new uint8_t[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = tData[5+k];
    }
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        for(auto tSg : tMsg) {
          uint64_t realValue;
          double rValue;
          if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
            uint8_t  data_len = tSg.getLength();
            uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
            uint8_t  data_num = tSg.getStartbit()/8;
            uint8_t  next_len =  data_len-head_len;
            uint32_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
            realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
            if(next_len > 0) {
              for(int m=0; m<(data_len-head_len)/8; m++) {
                next_len -= 8;
                realValue |= (tmpData[data_num+m+1]<<next_len);
              }
              realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
            } else {
              realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
            }

          } else {
            uint8_t  data_len = tSg.getLength();
            uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
            uint8_t  data_num = tSg.getStartbit()/8;
            uint8_t  next_len =  head_len;
            uint32_t lShiftS = pow(2,head_len);
            realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);
            if(next_len > 8) {
              for(int n=0; n<(data_len-head_len)/8; n++) {
                realValue |= tmpData[data_num+n+1]<<next_len;
                next_len += 8;
              }
              realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;
            } else {

            }

          }
          if(Sign::UNSIGNED == tSg.getSign()) {
            rValue = realValue*tSg.getFactor() + tSg.getOffset();

          } else {
            rValue = (int64_t)realValue*tSg.getFactor() + tSg.getOffset();
          }
          std::cout << "SG_Name: " << tSg.getName() <<std::endl;
          printf(" Value = %lf\n", rValue);
        }
      }

    }

  }


  //lcm.publish("UPSTREAMDBCSED", rdata);
}
