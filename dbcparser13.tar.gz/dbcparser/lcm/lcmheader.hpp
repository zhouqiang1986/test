#ifndef LCMHEADER_HPP_
#define LCMHEADER_HPP_

#include "lcmtypes/LongitudeAcc_t.hpp"
#include "lcmtypes/LateralAcce_t.hpp"

#endif
