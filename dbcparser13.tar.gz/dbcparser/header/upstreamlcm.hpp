#ifndef UPSTREAMLCM_HPP_
#define UPSTREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>
#include <mutex>
#include <boost/thread/mutex.hpp>

#include "dbciterator.hpp"
#include "lcmtypes/buffer_data_t.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"


class uplcmHandler {
public:
  uplcmHandler() {};
  uplcmHandler(DBCIterator *pdbc);
  virtual ~uplcmHandler() {};
  
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::buffer_data_t *msg);
  void rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                         const std::string& chan,
                         const lcmtypes::buffer_data_t *msg);
  void esrrearHandleMessage(const lcm::ReceiveBuffer *buf,
                            const std::string& chan,
                            const lcmtypes::buffer_data_t *msg);
  void canesrfrontHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void adcanHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void mobileeyeconHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);

public:
  lcmtypes::buffer_dbc_t buffer_dbc;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  std::mutex up_mutex[10];

private:
  uint64_t doConvert(Signal tSg, uint8_t tmpData[]);
  int64_t getCurrentTime();

public:
  void rsds_pub();
  void esrrear_pub();
  void canesrfront_pub();
  void adcan_pub();
  void mobileeyeifo_pub();
  void mobileeyecon_pub();
  void upstream_pub();

};

#endif
