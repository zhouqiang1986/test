#ifndef STREAMLCM_HPP_
#define STREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>
#include <mutex>
#include <boost/thread/mutex.hpp>
#include <string>
#include <map>
#include "dbciterator.hpp"
#include "signal.hpp"
#include "lcmtypes/buffer_data_t.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"


class lcmHandler {

typedef std::map<std::string, std::map<uint32_t, std::map<std::string, double>>> DBCDICT_t;
typedef std::map<std::string, std::map<uint32_t, std::map<std::string, double>>>::iterator DBCDICT_Ite;

typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

typedef std::map<std::string, std::vector<Message>> messages_t;
typedef std::map<std::string, std::vector<Message>>::iterator msgIte_t;

public:
  lcmHandler() {};
  lcmHandler(DBCIterator *pdbc);
  virtual ~lcmHandler() {};

  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::buffer_data_t *msg);
  void rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                         const std::string& chan,
                         const lcmtypes::buffer_data_t *msg);
  void esrrearHandleMessage(const lcm::ReceiveBuffer *buf,
                            const std::string& chan,
                            const lcmtypes::buffer_data_t *msg);
  void canesrfrontHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void adcanHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void mobileeyeconHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);

public:
  lcmtypes::buffer_dbc_t buffer_dbc;
  DBCDICT_t dbcDict;

private:
  //lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
  DBCIterator *pdbc_lcm;
  std::mutex up_mutex[10];

private:
  uint64_t doConvert(Signal tSg, uint8_t tmpData[]);
  void dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue);
  int64_t getCurrentTime();
  void getHexDataBuf(std::vector<Message> dbcList, std::vector<uint8_t>& tBuf_data, uint32_t msgId, std::string str, double mValue);
public:
  void rsds_pub();
  void esrrear_pub();
  void canesrfront_pub();
  void adcan_pub();
  void mobileeyeifo_pub();
  void mobileeyecon_pub();
  void tocamera_pub();
  void upstream_pub();

private:
  uint8_t send_mobile_eye_cmd_flag;
  double yaw_rate_ifo;
  double spe_out_ifo;

};

#endif
