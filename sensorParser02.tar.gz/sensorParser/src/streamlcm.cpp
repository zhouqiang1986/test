#include  "streamlcm.hpp"
#include "streamthread.hpp"

#include "lcmtypes/camera_info_t.hpp"
#include "lcmtypes/objects_t.hpp"
#include "lcmtypes/esr_objs_t.hpp"

lcmHandler::lcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;

  send_mobile_eye_cmd_flag = 0;
  yaw_rate_ifo = 0;
  spe_out_ifo = 0;
  //memset(obj_buf, 0, sizeof(obj_buf));
}

int64_t lcmHandler::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void lcmHandler::dorConvert(struct SSignal& tSg, uint8_t tData[], uint64_t hexValue) {
  if(ByteOrder::MOTOROLA == tSg.order) { //bigen
    uint8_t  data_len = tSg.length;
    uint8_t  head_len = (tSg.startBit%8+1)<data_len?(tSg.startBit%8+1):data_len;
    uint8_t  data_num = tSg.startBit/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue>>next_len)<<(tSg.startBit%8+1-head_len);
    if(next_len >= 8) {
      for(int i=0; i<(data_len-head_len)/8; i++) {
        next_len -= 8;
        tData[data_num+i+1] = (hexValue>>next_len)&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= (hexValue&((uint64_t)pow(2,next_len)-1))<<(8-next_len);
    }
  } else {
    uint8_t  data_len = tSg.length;
    uint8_t  head_len = (8-tSg.startBit%8)<data_len?(8-tSg.startBit%8):data_len;
    uint8_t  data_num = tSg.startBit/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue&((uint64_t)pow(2,head_len)-1))<<(tSg.startBit%8);
    if(next_len >= 8) {
      for(int j=0; j<(data_len-head_len)/8; j++) {
        next_len -= 8;
        tData[data_num+j+1] = (hexValue>>(head_len+j*8))&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= hexValue>>(data_len-next_len);
    }
  }
}

void lcmHandler::getHexDataBuf(messages_t& dbcList, uint8_t tData[], uint32_t msgId, std::string str, double mValue) {
  struct SSignal tSg = dbcList[msgId][str];
  uint64_t hexValue = (mValue-tSg.offset)/tSg.factor;
  dorConvert(tSg, tData, hexValue);
}

double lcmHandler::doGetRealValue(messages_t& dbcList, uint32_t msgId, std::string str, uint8_t tmpData[]) {
  struct SSignal& tSg = dbcList[msgId][str];
  return doConvert(tSg, tmpData)*tSg.factor + tSg.offset;
}

uint64_t lcmHandler::doConvert(struct SSignal& tSg, uint8_t tmpData[]) {
  uint64_t realValue;
  if(ByteOrder::MOTOROLA == tSg.order) { //bigen
    uint8_t  data_len = tSg.length;
    uint8_t  head_len = (tSg.startBit%8+1)<data_len?(tSg.startBit%8+1):data_len;
    uint8_t  data_num = tSg.startBit/8;
    uint8_t  next_len =  data_len-head_len;
    uint64_t lShiftF = pow(2,tSg.startBit%8+1+next_len);
    realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
    if(next_len > 0) {
      for(int m=0; m<(data_len-head_len)/8; m++) {
        next_len -= 8;
        realValue |= (tmpData[data_num+m+1]<<next_len);
      }
      realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
    } else {
      realValue = realValue>>(tSg.startBit%8+1-data_len);
    }

  } else {
    uint8_t  data_len = tSg.length;
    uint8_t  head_len = (8-tSg.startBit%8)<data_len?(8-tSg.startBit%8):data_len;
    uint8_t  data_num = tSg.startBit/8;
    uint8_t  next_len =  head_len;
    uint64_t lShiftS = pow(2,head_len);

    realValue = (tmpData[data_num]>>tSg.startBit%8)&(lShiftS-1);

    if((data_len-next_len) >= 8) {

      for(int n=0; n<(data_len-head_len)/8; n++) {
        realValue |= tmpData[data_num+n+1]<<next_len;
        next_len += 8;
      }
    }

    if((data_len-next_len) > 0) {
      realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;

    }
  }

  return realValue;
}

void lcmHandler::tocamera_pub() { //mobile eye cmd
  lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
  if(!lcm.good())
  {
    return ;
  }
  lcmtypes::buffer_data_t buffer_data;
  std::string sensor = "Sensor_CAN_MOBILE_RX";
  messages_t& dbcList = pdbc_lcm->msgsDict[sensor];
  uint8_t tData[8] = {0};
  uint8_t count = 0;
  send_mobile_eye_cmd_flag = 1;
  while(1) {
    //printf("tocamera_pub is running\n");
    usleep(50000);//20Hz

    if(send_mobile_eye_cmd_flag) {
      uint8_t i;
      std::vector<uint8_t> tBuf_data;
      tBuf_data.push_back(8);
      tBuf_data.push_back((0x330>>24)&0xff);
      tBuf_data.push_back((0x330>>16)&0xff);
      tBuf_data.push_back((0x330>>8)&0xff);
      tBuf_data.push_back(0x330&0xff);
      getHexDataBuf(dbcList, tData, 0x330, "msg330_RC", count);
      getHexDataBuf(dbcList, tData, 0x330, "YawRt_raw", yaw_rate_ifo);
      getHexDataBuf(dbcList, tData, 0x330, "IMULonAccPriAval", 1);
      getHexDataBuf(dbcList, tData, 0x330, "IMULonAccSecAval", 1);
      getHexDataBuf(dbcList, tData, 0x330, "msg330_CS", 0);
      for(i=0; i<8; i++) {
        tBuf_data.push_back(tData[i]);
      }
      memset(tData, 0, sizeof(tData));
      tBuf_data.push_back(8);
      tBuf_data.push_back((0x340>>24)&0xff);
      tBuf_data.push_back((0x340>>16)&0xff);
      tBuf_data.push_back((0x340>>8)&0xff);
      tBuf_data.push_back(0x340&0xff);
      getHexDataBuf(dbcList, tData, 0x340, "msg340_RC", count);
      getHexDataBuf(dbcList, tData, 0x340, "VARIABLE_1", 1);
      getHexDataBuf(dbcList, tData, 0x340, "VARIABLE_2", 3);
      getHexDataBuf(dbcList, tData, 0x340, "YawRt_raw", abs(yaw_rate_ifo));
      getHexDataBuf(dbcList, tData, 0x340, "VARIABLE_3", 1);
      getHexDataBuf(dbcList, tData, 0x340, "msg340_CS", 0);
      for(i=0; i<8; i++) {
        tBuf_data.push_back(tData[i]);
      }
      memset(tData, 0, sizeof(tData));
      tBuf_data.push_back(8);
      tBuf_data.push_back((0x3E9>>24)&0xff);
      tBuf_data.push_back((0x3E9>>16)&0xff);
      tBuf_data.push_back((0x3E9>>8)&0xff);
      tBuf_data.push_back(0x3E9&0xff);
      getHexDataBuf(dbcList, tData, 0x3E9, "VehSpdAvgDrvn_PB_raw", spe_out_ifo);
      getHexDataBuf(dbcList, tData, 0x3E9, "VehSpdAvgDrvn_PB_raw2", spe_out_ifo);
      for(i=0; i<8; i++) {
        tBuf_data.push_back(tData[i]);
      }
      memset(tData, 0, sizeof(tData));
      uint16_t checksum;
      //std::cout<<"tBuf_data.size():"<<tBuf_data.size()<<std::endl;
      for(i=0; i<tBuf_data.size()/13; i++) {
        checksum = (tBuf_data[i*13+5]+tBuf_data[i*13+6]+tBuf_data[i*13+7]+tBuf_data[i*13+8]+tBuf_data[i*13+9]+tBuf_data[i*13+10])+tBuf_data[i*13+11]&0xF8+(((tBuf_data[i*13+1]<<24)+(tBuf_data[i*13+2]<<16)+(tBuf_data[i*13+3]<<8)+tBuf_data[i*13+4])>>3);
        tBuf_data[i*13+11] |= (checksum>>8)&0x3;
        tBuf_data[i*13+12] = checksum&0xFF;
      }
      buffer_data.data.insert(buffer_data.data.end(), tBuf_data.begin(), tBuf_data.end());
      buffer_data.utime = getCurrentTime();
      buffer_data.data_length = buffer_data.data.size();
      lcm.publish("TO_CAMERA", &buffer_data);
      buffer_data.data.clear();
      count = count<3 ? count+1 : 0;
    }
  }
}
/*
void lcmHandler::upstream_pub() {
  lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
  while(1) {
    //printf("upstreampub is running\n");
    usleep(100000);//10Hz

    up_mutex[0].lock();
    buffer_dbc.utime = getCurrentTime();
    buffer_dbc.data_length = buffer_dbc.data.size();
    //std::cout<<"handleMessage:"<<buffer_dbc.data_length<<std::endl;
    lcm.publish("UPSTREAMDBCSED", &buffer_dbc);
    buffer_dbc.data.clear();
    buffer_dbc.data_length = buffer_dbc.data.size();
    up_mutex[0].unlock();
  }
}
*/

void lcmHandler::mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *rdata)
{
  //printf("Received message on channel \"%s\":\n", chan.c_str());
  std::string sensor = channelToSensor[chan];
  messages_t& dbcList = pdbc_lcm->msgsDict[sensor];
  //std::map<uint32_t, std::map<std::string, double>>& msgList = dbcDict[chan];
  if(chan == "CAN_RSDS_RAW_DATA") {
    messages_t& dbcList_cl = pdbc_lcm->msgsDict["Sensor_CAN_Radar_CL"];
    messages_t& dbcList_cr = pdbc_lcm->msgsDict["Sensor_CAN_Radar_CR"];
    messages_t& dbcList_rl = pdbc_lcm->msgsDict["Sensor_CAN_Radar_RL"];
    messages_t& dbcList_rr = pdbc_lcm->msgsDict["Sensor_CAN_Radar_RR"];
    static double objs_buf[128][10] = {0};
    uint32_t xIndex;
    //std::map<uint32_t, std::map<std::string, double>>& msgList = dbcDict[chan];
    sigs_t sigs;
    sigIte_t tSg;
    double rValue;
    //std::map<std::string, double> sIg;
    for(int i=0; i<(rdata->data_length/13); i++)
    {
      uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
      if(dataId >= 0x457 && dataId <= 0x476) {//CL
        sigs = dbcList_cl[dataId];
        xIndex = dataId - 0x457;
      } else if(dataId >= 0x501 && dataId <= 0x520) {//CR
        sigs = dbcList_cr[dataId];
        xIndex = dataId - 0x501 + 32;
      } else if(dataId >= 0x531 && dataId <= 0x54A) {//RL
        sigs = dbcList_rl[dataId];
        xIndex = dataId - 0x531 + 32 + 32;
      } else if(dataId >= 0x55B && dataId <= 0x560) {//RL
        sigs = dbcList_rl[dataId];
        xIndex = dataId - 0x55B + 32 + 32 + 26;
      } else if(dataId >= 0x601 && dataId <= 0x619) {//RR
        sigs = dbcList_rr[dataId];
        xIndex = dataId - 0x601 + 32 + 32 + 26 + 6;
      } else if(dataId >= 0x62A && dataId <= 0x630) {//RR
        sigs = dbcList_rr[dataId];
        xIndex = dataId - 0x55B + 32 + 32 + 26 + 6 + 25;
      } else {
        continue;
      }
      uint8_t tmpData[8];
      for(int k=0; k<8; k++) {
        tmpData[k] = rdata->data[5+k+i*13];
      }
      int yIndex = 0;
      for(tSg=sigs.begin(); tSg!=sigs.end(); tSg++) {
        std::string str = tSg->first.substr(11);
        if("Vx" == str) {
          yIndex = 2;
        } else if("ID" == str) {
          yIndex = 0;
        } else if("dy" == str) {
          yIndex = 8;
        } else if("dx" == str) {
          yIndex = 9;
        } else {
          continue;
        }
        rValue = doConvert(tSg->second, tmpData)*tSg->second.factor + tSg->second.offset;
        objs_buf[xIndex][yIndex] = rValue;
        //sIg[tSg->second.name] = rValue;
      }
      //msgList[dataId] = sIg;
      //sIg.clear();
      if(dataId == 0x476 || dataId == 0x520 || dataId == 0x560 || dataId == 0x630) {
        lcmtypes::objects_t objects;
        lcmtypes::point_obj_t po;
        for(int i=0; i<128; i++) {
          po.x = objs_buf[i][9];
          po.y = objs_buf[i][8];
          po.angle = objs_buf[i][2];
          objects.objects.push_back(po);
        }
        objects.object_number = objects.objects.size();
        /*
        lcmtypes::esr_objs_t esr_objs;
        lcmtypes::esr_obj_t po;
        for(int l=0; l<128; l++) {
          po.obj_id = objs_buf[l][0];
          po.obj_x = objs_buf[l][9];
          po.obj_y = objs_buf[l][8];
          po.obj_vx = objs_buf[l][2];
          po.obj_vy = 0;
          po.obj_acc = 0;
          po.obj_width = 1;
          po.obj_status = 2;
          esr_objs.objs.push_back(po);
        }
        esr_objs.utime = getCurrentTime();
        esr_objs.objs_count = esr_objs.objs.size(); */
        lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
        if(!lcm.good())
        {
          return ;
        }
        lcm.publish("RSDS_WHOLE_DATA", &objects);
        //lcm.publish("RSDS_WHOLE_DATA", &esr_objs);
      }
    }
    /*
    messages_t& dbcList_cl = pdbc_lcm->msgsDict["Sensor_CAN_Radar_CL"];
    messages_t& dbcList_cr = pdbc_lcm->msgsDict["Sensor_CAN_Radar_CR"];
    messages_t& dbcList_rl = pdbc_lcm->msgsDict["Sensor_CAN_Radar_RL"];
    messages_t& dbcList_rr = pdbc_lcm->msgsDict["Sensor_CAN_Radar_RR"];
    lcmtypes::buffer_data_t buffer_data_cl;
    lcmtypes::buffer_data_t buffer_data_cr;
    lcmtypes::buffer_data_t buffer_data_rl;
    lcmtypes::buffer_data_t buffer_data_rr;
    uint8_t l, m;
    for(int i=0; i<(rdata->data_length/13); i++)
    {
      msgIte_t tMsg;
      uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
      l = 0;
      for(tMsg=dbcList_cl.begin(); tMsg!=dbcList_cl.end(); tMsg++) {
        if(dataId == tMsg->first) {
          for(m=0; m<13; m++) {
            buffer_data_cl.data.push_back(rdata->data[m+i*13]);
          }
          l = 1;
          break;
        }
      }
      if(l) {
        continue;
      }
      for(tMsg=dbcList_cr.begin(); tMsg!=dbcList_cr.end(); tMsg++) {
        if(dataId == tMsg->first) {
          for(m=0; m<13; m++) {
            buffer_data_cr.data.push_back(rdata->data[m+i*13]);
          }
          l = 1;
          break;
        }
      }
      if(l) {
        continue;
      }
      for(tMsg=dbcList_rl.begin(); tMsg!=dbcList_rl.end(); tMsg++) {
        if(dataId == tMsg->first) {
          for(m=0; m<13; m++) {
            buffer_data_rl.data.push_back(rdata->data[m+i*13]);
          }
          l = 1;
          break;
        }
      }
      if(l) {
        continue;
      }
      for(tMsg=dbcList_rr.begin(); tMsg!=dbcList_rr.end(); tMsg++) {
        if(dataId == tMsg->first) {
          for(m=0; m<13; m++) {
            buffer_data_rr.data.push_back(rdata->data[m+i*13]);
          }
          break;
        }
      }
    }

    lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
    if(!lcm.good())
    {
      return ;
    }

    buffer_data_cl.utime = getCurrentTime();
    buffer_data_cl.data_length = buffer_data_cl.data.size();
    lcm.publish("RSDS_LEFTFRONT_DATA", &buffer_data_cl);
    //buffer_data_cl.data.clear();

    buffer_data_cr.utime = getCurrentTime();
    buffer_data_cr.data_length = buffer_data_cr.data.size();
    lcm.publish("RSDS_RIGHTFRONT_DATA", &buffer_data_cr);
    //buffer_data_cr.data.clear();

    buffer_data_rl.utime = getCurrentTime();
    buffer_data_rl.data_length = buffer_data_rl.data.size();
    lcm.publish("RSDS_LEFTREAR_DATA", &buffer_data_rl);
    //buffer_data_rl.data.clear();

    buffer_data_rr.utime = getCurrentTime();
    buffer_data_rr.data_length = buffer_data_rr.data.size();
    lcm.publish("RSDS_RIGHTREAR_DATA", &buffer_data_rr);
    //buffer_data_rr.data.clear();

    return ; */

  } else if(sensor == "Sensor_CAN_ESR_REAR_DAOYUAN" || sensor == "Sensor_CAN_ESR_FRONT") { //ESR
      static double obj_buf[64][15] = {0};
      //struct SSignal tSg;
      std::string id_label[64];
      char tCHAR[2];
      int j;
      for(j=0; j<64; j++) {
        sprintf(tCHAR, "%02i", j+1);
        id_label[j] = tCHAR;
      }
      for(int i=0; i<(rdata->data_length/13); i++)
      {
        uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
        uint8_t tmpData[8];
        for(int k=0; k<8; k++) {
          tmpData[k] = rdata->data[5+k+i*13];
        }
        if(dataId <= 0x53f && dataId >= 0x500) {
          uint32_t obj_id = dataId - 0x500;
          obj_buf[obj_id][0] = obj_id;
          obj_buf[obj_id][1] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_RANGE", tmpData);
          obj_buf[obj_id][2] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_RANGE_RATE", tmpData);
          obj_buf[obj_id][3] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_ANGLE", tmpData);
          obj_buf[obj_id][4] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_WIDTH", tmpData);
          obj_buf[obj_id][5] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_MED_RANGE_MODE", tmpData);
        }
        if(dataId == 0x540) {
          //std::cout<<"dataId="<<dataId<<std::endl;
          uint8_t track_group_id = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_CAN_ID_GROUP", tmpData);
          if(track_group_id < 9) {
            for(int i=0; i<7; i++) {
              obj_buf[i+track_group_id*7][6] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_MOVING"+id_label[i+track_group_id*7], tmpData);
              obj_buf[i+track_group_id*7][7] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_POWER"+id_label[i+track_group_id*7], tmpData);
            }
          } else {
            obj_buf[63][6] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_MOVING"+id_label[63], tmpData);
            obj_buf[63][7] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_MOVING"+id_label[63], tmpData);
            double tem_angle;
            for(int j=0; j<64; j++) {
              if(sensor == "Sensor_CAN_ESR_REAR_DAOYUAN") {
                tem_angle = deg2rad(obj_buf[j][3]+180);
              } else {
                tem_angle = deg2rad(obj_buf[j][3]+0);
              }
              obj_buf[j][8] = obj_buf[j][1]*sin(tem_angle) + 0;
              obj_buf[j][9] = obj_buf[j][1]*cos(tem_angle) + 0;
            }
            lcmtypes::objects_t objects;
            lcmtypes::point_obj_t po;
            double tp[10];
            for(int i=0; i<64; i++) {
              if(obj_buf[i][1]!=0) {
                for(int k=0; k<10; k++) {
                  tp[k] = obj_buf[i][k];
                }
                po.x = tp[8];
                po.y = tp[9];
                po.angle = tp[2];
                objects.objects.push_back(po);
              }
            }
            objects.object_number = objects.objects.size();
            lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
            if(!lcm.good())
            {
              return ;
            }
            if(sensor == "Sensor_CAN_ESR_REAR_DAOYUAN") {
              //std::cout<<"Sensor_CAN_ESR_REAR_DAOYUAN"<<std::endl;
              lcm.publish("ESR_REAR_WHOLE_DATA", &objects);
            } else if (sensor == "Sensor_CAN_ESR_FRONT") {
              //std::cout<<"Sensor_CAN_ESR_FRONT"<<std::endl;
              lcm.publish("ESR_FRONT_WHOLE_DATA", &objects);
            }
          }
        }
      }
      /*
      for(int i=0; i<(rdata->data_length/13); i++)
      {
        uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
        uint8_t tmpData[8];
        for(int k=0; k<8; k++) {
          tmpData[k] = rdata->data[5+k+i*13];
        }
        // id range rrate angle width MM acc status MF TP  x  y  vx  vy
        // 0    1      2    3     4    5  6     7   8  9  10  11 12  13
        uint32_t obj_id = dataId - 0x500;
        if(obj_id >= 0 && obj_id < 64) {
          obj_buf[obj_id][13] = obj_id;
          if((doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_RANGE", tmpData)==0) || (doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_STATUS", tmpData)==0)) {
            for(int n=0; n<15; n++) {
              obj_buf[obj_id][n] = 0;
            }
          } else {
            obj_buf[obj_id][9] += 1;
            obj_buf[obj_id][0] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_ANGLE", tmpData);
            obj_buf[obj_id][1] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_RANGE", tmpData);
            obj_buf[obj_id][2] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_RANGE_RATE", tmpData);
            obj_buf[obj_id][10] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_LAT_RATE", tmpData);
            obj_buf[obj_id][11] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_RANGE_ACCEL", tmpData);
            obj_buf[obj_id][12] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_WIDTH", tmpData);
            obj_buf[obj_id][14] = doGetRealValue(dbcList, dataId, "CAN_TX_TRACK_STATUS", tmpData);
          }
        }
        if(obj_id == 63) {
          for(int j=0; j<64; j++) {
            obj_buf[j][0] = deg2rad(obj_buf[j][0]);
            obj_buf[j][3] = obj_buf[j][1]*sin(obj_buf[j][0]);
            obj_buf[j][4] = obj_buf[j][1]*cos(obj_buf[j][0]);
            //obj_buf[obj_id][5] = 0;
            if(sensor == "Sensor_CAN_ESR_REAR_DAOYUAN") {
              obj_buf[j][6] = obj_buf[j][3]*(-1) + 0;
              obj_buf[j][7] = obj_buf[j][4]*(-1) + 0;
              obj_buf[j][8] = obj_buf[j][5]*(1) + 0;
            } {
              obj_buf[j][6] = obj_buf[j][3]*(1) + 0;
              obj_buf[j][7] = obj_buf[j][4]*(1) + 0;
              obj_buf[j][8] = obj_buf[j][5]*(1) + 0;
            }
          }
          lcmtypes::esr_objs_t esr_objs;
          lcmtypes::esr_obj_t po;
          for(int l=0; l<64; l++) {
            if(obj_buf[l][9]>2) {
              po.obj_id = obj_buf[l][13];
              po.obj_x = obj_buf[l][6];
              po.obj_y = obj_buf[l][7];
              po.obj_vx = obj_buf[l][10];
              po.obj_vy = obj_buf[l][2];
              po.obj_acc = obj_buf[l][11];
              po.obj_width = obj_buf[l][12];
              po.obj_status = obj_buf[l][14];
              esr_objs.objs.push_back(po);
            }
          }
          esr_objs.utime = getCurrentTime();
          esr_objs.objs_count = esr_objs.objs.size();
          lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
          if(!lcm.good())
          {
            return ;
          }
          if(sensor == "Sensor_CAN_ESR_REAR_DAOYUAN") {
            lcm.publish("ESR_REAR_WHOLE_DATA", &esr_objs);
          } else if (sensor == "Sensor_CAN_ESR_FRONT") {
            lcm.publish("ESR_FRONT_WHOLE_DATA", &esr_objs);
          }
        }
      }*/
    } else if(sensor == "Sensor_CAN_MOBILE_TX") { //mobile eye inifo
      std::map<uint32_t, std::map<std::string, double>>& msgList = dbcDict[chan];
      sigs_t sigs;
      sigIte_t tSg;
      double rValue;
      uint8_t tmpData[8];
      std::map<std::string, double> sIg;
      for(int i=0; i<(rdata->data_length/13); i++)
      {
        uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
        for(int k=0; k<8; k++) {
          tmpData[k] = rdata->data[5+k+i*13];
        }
        sigs = dbcList[dataId];
        for(tSg=sigs.begin(); tSg!=sigs.end(); tSg++) {
          rValue = doConvert(tSg->second, tmpData)*tSg->second.factor + tSg->second.offset;
          sIg[tSg->second.name] = rValue;
        }
        msgList[dataId] = sIg;
        sIg.clear();
      }
      lcmtypes::camera_info_t camera_info;
      camera_info.utime = getCurrentTime();
      std::map<std::string, double> msg_6A4 = msgList[0x6A4];
      camera_info.lines[1].type = msg_6A4["VIS_LANE_LEFT_PARALL_TYPE"];
      camera_info.lines[2].type = msg_6A4["VIS_LANE_RIGHT_PARALL_TYPE"];
      if(msg_6A4["VIS_LANE_LANE_CHANGE"] == 1) {
        camera_info.change_lane = 1;
      } else {
        camera_info.change_lane = 0;
      }
      std::map<std::string, double> msg_6A5 = msgList[0x6A5];
      camera_info.center_line.a = msg_6A5["VIS_CENTER_POLYNOMIAL_A0"];
      camera_info.center_line.b = msg_6A5["VIS_CENTER_POLYNOMIAL_A1"];
      camera_info.center_line.c = msg_6A5["VIS_CENTER_POLYNOMIAL_A2"];
      camera_info.center_line.d = msg_6A5["VIS_CENTER_POLYNOMIAL_A3"];
      camera_info.lane_width = msg_6A5["VIS_CENTER_POLYNOMIAL_WIDTH"];
      std::map<std::string, double> msg_6A9 = msgList[0x6A9];
      camera_info.lines[0].a = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A0"];
      camera_info.lines[0].b = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A1"];
      camera_info.lines[0].c = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A2"];
      camera_info.lines[0].d = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A3"];
      camera_info.lines[0].length = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_RANGE"];
      std::map<std::string, double> msg_6A7 = msgList[0x6A7];
      camera_info.lines[1].a = msg_6A7["VIS_LANE_LEFT_PARALL_A0"];
      camera_info.lines[1].b = msg_6A7["VIS_LANE_LEFT_PARALL_A1"];
      camera_info.lines[1].c = msg_6A7["VIS_LANE_LEFT_PARALL_A2"];
      camera_info.lines[1].d = msg_6A7["VIS_LANE_LEFT_PARALL_A3"];
      camera_info.lines[1].length = msg_6A7["VIS_LANE_LEFT_PARALL_RANGE"];
      std::map<std::string, double> msg_6A6 = msgList[0x6A6];
      camera_info.lines[2].a = msg_6A6["VIS_LANE_RIGHT_PARALL_A0"];
      camera_info.lines[2].b = msg_6A6["VIS_LANE_RIGHT_PARALL_A1"];
      camera_info.lines[2].c = msg_6A6["VIS_LANE_RIGHT_PARALL_A2"];
      camera_info.lines[2].d = msg_6A6["VIS_LANE_RIGHT_PARALL_A3"];
      camera_info.lines[2].length = msg_6A6["VIS_LANE_RIGHT_PARALL_RANGE"];
      std::map<std::string, double> msg_6A8 = msgList[0x6A8];
      camera_info.lines[3].a = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A0"];
      camera_info.lines[3].b = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A1"];
      camera_info.lines[3].c = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A2"];
      camera_info.lines[3].d = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A3"];
      camera_info.lines[3].length = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_RANGE"];

      camera_info.object_count = 15;
      camera_info.objects.resize(camera_info.object_count);
      std::map<std::string, double> msg_677 = msgList[0x677];
      std::string id_label[camera_info.object_count];
      char tCHAR[2];
      int j;
      for(j=0; j<camera_info.object_count; j++) {
        sprintf(tCHAR, "%02i", j+1);
        id_label[j] = tCHAR;
        //std::cout<<id_label[j]<<std::endl;
      }
      j=0;
      for(auto obj : camera_info.objects) {
        obj.width = msg_677["VIS_OBS_WIDTH_01"+id_label[j]];
        obj.centerPoint.y = msg_677["VIS_OBS_LONG_POS_"+id_label[j]];
        obj.centerPoint.x = msg_677["VIS_OBS_LAT_POS_"+id_label[j]];
        obj.speedLat = msg_677["VIS_OBS_LAT_VEL_"+id_label[j]];
        obj.speedLon = msg_677["VIS_OBS_LONG_VEL_"+id_label[j]];
        j++;
      }
      camera_info.center_line.length = std::max(camera_info.lines[1].length, camera_info.lines[2].length);
      lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
      if(!lcm.good())
      {
        return ;
      }
      lcm.publish("camera", &camera_info);
    } else if(sensor == "Sensor_CAN_Radar_CL" || sensor == "Sensor_CAN_Radar_CR" || sensor == "Sensor_CAN_Radar_RL" || sensor == "Sensor_CAN_Radar_RR") { //角雷达
      std::cout<<sensor<<std::endl;
    }
}
/*
void lcmHandler::mobileeyeconHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}
*/
/*
void lcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  std::vector< lcmtypes::buffer_message_t > tBuffer_dbc;
  lcmtypes::buffer_message_t buffer_message;

  std::vector<Message> dbcList = pdbc_lcm->messageList.find("Sensor_AD_OBD_B_CAN")->second;

  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    std::cout<<dataId<<std::endl;
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }

    buffer_message.sigMap.clear();

    for(auto tMsg : dbcList) {
      if(dataId == tMsg.getId()) {
        buffer_message.id = dataId;
        double rValue;
        lcmtypes::map_data_t sigMap;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sigMap.sigName = tSg.getName();
          sigMap.sigValue = rValue;
          buffer_message.sigMap.push_back(sigMap);
        }
        buffer_message.sigCnt = buffer_message.sigMap.size();
        tBuffer_dbc.push_back(buffer_message);
      }

    }

  }

  up_mutex[0].lock();
  buffer_dbc.data.clear();
  buffer_dbc.data.insert(buffer_dbc.data.begin(), tBuffer_dbc.begin(), tBuffer_dbc.end());
  up_mutex[0].unlock();

} */
