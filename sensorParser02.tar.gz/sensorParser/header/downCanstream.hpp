#ifndef DOWNCANSTREAM_HPP_
#define DOWNCANSTREAM_HPP_

#include <lcm/lcm-cpp.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <mutex>
#include <utility>
#include <map>
#include "dbciterator.hpp"

class downCanstream {

  typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
  typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;

  typedef std::map<std::string, std::vector<Message>> messages_t;
  typedef std::map<std::string, std::vector<Message>>::iterator msgIte_t;

public:
  downCanstream(DBCIterator *pdbc);
  virtual ~downCanstream();

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  boost::thread_group threadGp;
  int cansock_fd;

public:
  void downCan_sub();
  void downCan_pub();

};

#endif
