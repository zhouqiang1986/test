#include  "upstreamlcm.hpp"
#include "signal.hpp"
#include "upstreamthread.hpp"
#include <math.h>

#include "lcmtypes/camera_info_t.hpp"

uplcmHandler::uplcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

int64_t uplcmHandler::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void uplcmHandler::rsds_pub() {
  while(1) {
    //printf("rsds_pub is running\n");
    usleep(100000);//10Hz

  }
}

void uplcmHandler::esrrear_pub() {
  while(1) {
    //printf("esrrear_pub is running\n");
    usleep(100000);//10Hz
  }
}

void uplcmHandler::canesrfront_pub() {
  while(1) {
    //printf("canesrfront_pub is running\n");
    usleep(100000);//10Hz
  }
}

void uplcmHandler::adcan_pub() {
  while(1) {
    //printf("adcan_pub is running\n");
    usleep(100000);//10Hz
  }
}

void uplcmHandler::mobileeyeifo_pub() {

  while(1) {
    //printf("mobileeyeifo_pub is running\n");
    usleep(100000);//10Hz
    /*
    std::vector<Message> dbcList = pdbc_lcm->messageList.find("Sensor_AD_OBD_B_CAN")->second;
    for(auto message : dbcList) {
        std::cout << message.getName() << " " << message.getId() << std::endl;
        for(auto sig : message) {
            std::cout << "Signal: " << sig.getName() << "  ";
            std::cout << "To: ";
            for (auto to : sig.getTo()) {
                std::cout << to << ", ";
            }
            std::cout << sig.getStartbit() << "," << sig.getLength() << std::endl;
            std::cout << "(" << sig.getFactor() << ", " << sig.getOffset() << ")" << std::endl;
            std::cout << "[" << sig.getMinimum() << "," << sig.getMaximum() << "]" << std::endl;
            if (sig.getMultiplexor() == Multiplexor::MULTIPLEXED) {
                std::cout << "#" << sig.getMultiplexedNumber() << "#" << std::endl;
            } else if (sig.getMultiplexor() == Multiplexor::MULTIPLEXOR) {
                std::cout << "+Multiplexor+" << std::endl;
            }
            std::cout << std::endl;
        };
    }*/
    /*
    DBCDICT_t::iterator dbcdictIte;
    std::map<uint32_t, std::map<std::string, double>> msgList;
    std::map<uint32_t, std::map<std::string, double>>::iterator ite;
    std::map<std::string, double>::iterator sigite;

    if((dbcdictIte = dbcDict.find("Sensor_AD_OBD_B_CAN")) != dbcDict.end()) {
      //std::cout<<dbcdictIte->first<<std::endl;
      msgList = dbcdictIte->second;
      for(ite = msgList.begin(); ite != msgList.end(); ite++) {
        std::cout<<"id:"<<ite->first<<std::endl;
        for(sigite = ite->second.begin(); sigite != ite->second.end(); sigite++) {
          std::cout<<"sigName:"<<sigite->first<<"sigValue:"<<sigite->second<<std::endl;
        }
      }
    }*/
  }
}

void uplcmHandler::mobileeyecon_pub() {
  while(1) {
    //printf("mobileeyecon_pub is running\n");
    usleep(100000);//10Hz
  }
}

void uplcmHandler::upstream_pub() {
  while(1) {
    //printf("upstreampub is running\n");
    usleep(100000);//10Hz

    up_mutex[0].lock();
    buffer_dbc.utime = getCurrentTime();
    buffer_dbc.data_length = buffer_dbc.data.size();
    lcm.publish("UPSTREAMDBCSED", &buffer_dbc);
    buffer_dbc.data.clear();
    buffer_dbc.data_length = buffer_dbc.data.size();
    up_mutex[0].unlock();
  }
}

uint64_t uplcmHandler::doConvert(Signal tSg, uint8_t tmpData[]) {
  uint64_t realValue;
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    uint64_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
    realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
    if(next_len > 0) {
      for(int m=0; m<(data_len-head_len)/8; m++) {
        next_len -= 8;
        realValue |= (tmpData[data_num+m+1]<<next_len);
      }
      realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
    } else {
      realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
    }

  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  head_len;
    uint64_t lShiftS = pow(2,head_len);

    realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);

    if((data_len-next_len) >= 8) {

      for(int n=0; n<(data_len-head_len)/8; n++) {
        realValue |= tmpData[data_num+n+1]<<next_len;
        next_len += 8;
      }
    }

    if((data_len-next_len) > 0) {
      realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;

    }
  }

  return realValue;
}

void uplcmHandler::rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                       const std::string& chan,
                       const lcmtypes::buffer_data_t *msg)
{

}

void uplcmHandler::esrrearHandleMessage(const lcm::ReceiveBuffer *buf,
                          const std::string& chan,
                          const lcmtypes::buffer_data_t *msg)
{

}

void uplcmHandler::canesrfrontHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void uplcmHandler::adcanHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void uplcmHandler::mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *rdata)
{
  //printf("Received message on channel \"%s\":\n", chan.c_str());
  std::map<uint32_t, std::map<std::string, double>> k_v;
  std::string sensor;
  cfgListIte_t cfgIte = pdbc_lcm->cfgList->begin();
  while(cfgIte != pdbc_lcm->cfgList->end()) {

    if(cfgIte->second.find("lcm_channel") != cfgIte->second.end()) {
      if(cfgIte->second.find("lcm_channel")->second.compare(chan) == 0) {
        sensor = cfgIte->first;
        dbcDict.insert(std::make_pair(cfgIte->first, k_v));
      }
    }
    cfgIte++;
  }

  std::vector<Message> dbcList = pdbc_lcm->messageList.find(sensor)->second;
  std::map<uint32_t, std::map<std::string, double>>& msgList = dbcDict.find(sensor)->second;
  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }
    for(auto tMsg : dbcList) {
      if(dataId == tMsg.getId()) {
        double rValue;
        std::map<std::string, double> sIg;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sIg[tSg.getName()] = rValue;
        }
        msgList[dataId] = sIg;
      }
    }
  }

  lcmtypes::camera_info_t camera_info;
  camera_info.utime = getCurrentTime();
  std::map<std::string, double> msg_6A4 = msgList[0x6A4];
  camera_info.lines[1].type = msg_6A4["VIS_LANE_LEFT_PARALL_TYPE"];
  camera_info.lines[2].type = msg_6A4["VIS_LANE_RIGHT_PARALL_TYPE"];
  camera_info.change_lane = ?;//self.parser.g_change_lane
  std::map<std::string, double> msg_6A5 = msgList[0x6A5];
  camera_info.center_line.a = msg_6A5["VIS_CENTER_POLYNOMIAL_A0"];
  camera_info.center_line.b = msg_6A5["VIS_CENTER_POLYNOMIAL_A1"];
  camera_info.center_line.c = msg_6A5["VIS_CENTER_POLYNOMIAL_A2"];
  camera_info.center_line.d = msg_6A5["VIS_CENTER_POLYNOMIAL_A3"];
  camera_info.lane_width = msg_6A5["VIS_CENTER_POLYNOMIAL_WIDTH"];
  std::map<std::string, double> msg_6A9 = msgList[0x6A9];
  camera_info.lines[0].a = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A0"];
  camera_info.lines[0].b = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A1"];
  camera_info.lines[0].c = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A2"];
  camera_info.lines[0].d = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_A3"];
  camera_info.lines[0].length = msg_6A9["VIS_LANE_LEFT_NEIGHBOR_RANGE"];
  std::map<std::string, double> msg_6A7 = msgList[0x6A7];
  camera_info.lines[1].a = msg_6A7["VIS_LANE_LEFT_PARALL_A0"];
  camera_info.lines[1].b = msg_6A7["VIS_LANE_LEFT_PARALL_A1"];
  camera_info.lines[1].c = msg_6A7["VIS_LANE_LEFT_PARALL_A2"];
  camera_info.lines[1].d = msg_6A7["VIS_LANE_LEFT_PARALL_A3"];
  camera_info.lines[1].length = msg_6A7["VIS_LANE_LEFT_PARALL_RANGE"];
  std::map<std::string, double> msg_6A6 = msgList[0x6A6];
  camera_info.lines[2].a = msg_6A6["VIS_LANE_RIGHT_PARALL_A0"];
  camera_info.lines[2].b = msg_6A6["VIS_LANE_RIGHT_PARALL_A1"];
  camera_info.lines[2].c = msg_6A6["VIS_LANE_RIGHT_PARALL_A2"];
  camera_info.lines[2].d = msg_6A6["VIS_LANE_RIGHT_PARALL_A3"];
  camera_info.lines[2].length = msg_6A6["VIS_LANE_RIGHT_PARALL_RANGE"];
  std::map<std::string, double> msg_6A8 = msgList[0x6A8];
  camera_info.lines[3].a = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A0"];
  camera_info.lines[3].b = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A1"];
  camera_info.lines[3].c = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A2"];
  camera_info.lines[3].d = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_A3"];
  camera_info.lines[3].length = msg_6A8["VIS_LANE_RIGHT_NEIGHBOR_RANGE"];
  std::map<std::string, double> msg_677 = msgList[0x677];

  camera_info.object_count = 15;

  if(!lcm.good())
  {
    return ;
  }
  lcm.publish("camera", &camera_info);
}

void uplcmHandler::mobileeyeconHandleMessage(const lcm::ReceiveBuffer *buf,
                              const std::string& chan,
                              const lcmtypes::buffer_data_t *msg)
{

}

void uplcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  std::vector< lcmtypes::buffer_message_t > tBuffer_dbc;
  lcmtypes::buffer_message_t buffer_message;

  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }

    buffer_message.sigMap.clear();
    /*
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        buffer_message.id = dataId;
        double rValue;
        lcmtypes::map_data_t sigMap;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sigMap.sigName = tSg.getName();
          sigMap.sigValue = rValue;
          buffer_message.sigMap.push_back(sigMap);
        }
        buffer_message.sigCnt = buffer_message.sigMap.size();
        tBuffer_dbc.push_back(buffer_message);
      }

    } */

  }

  up_mutex[0].lock();
  buffer_dbc.data.clear();
  buffer_dbc.data.insert(buffer_dbc.data.begin(), tBuffer_dbc.begin(), tBuffer_dbc.end());
  up_mutex[0].unlock();

}
