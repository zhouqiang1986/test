#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>

#include "downstreamthread.hpp"
#include "downstreamlcm.hpp"

downThread::downThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

downThread::~downThread() {

}

void downThread::run() {
  if(!lcm.good())
  {
    return ;
  }

  downlcmHandler downlcmHandlerObject(pdbc_lcm);
  //lcm.subscribe("DOWNSTREAMDBCREC", &downlcmHandler::handleMessage, &downlcmHandlerObject);
  cfgListIte_t cfgite;
  msgIte_t msgite;
  for(msgite=pdbc_lcm->messageList.begin(); msgite != pdbc_lcm->messageList.end(); msgite++) {
    if((cfgite=pdbc_lcm->cfgList->find(msgite->first)) != pdbc_lcm->cfgList->end()) {
      if(cfgite->second.find("lcm_rx_channel") != cfgite->second.end()) {
        std::string lcm_channel = cfgite->second.find("lcm_rx_channel")->second;
        if(!lcm_channel.empty() && lcm_channel.size()>1) {
          std::cout<<"!channel:"<<lcm_channel<<"   size:"<<lcm_channel.size()<<std::endl;
          lcm.subscribe(lcm_channel, &downlcmHandler::tocameraHandleMessage, &downlcmHandlerObject);
        }
      }
    }
  }
  //lcm.subscribe("CAN_RSDS_RAW_DATA", &downlcmHandler::rsdsHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_DAOYUAN_CMD", &downlcmHandler::todaoyuanHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_POWER_CONTROL", &downlcmHandler::topowerconHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_VEHICLE_CONTROL", &downlcmHandler::tovehconHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("CAN_MOBILE_TX", &downlcmHandler::mobileeyeifoHandleMessage, &downlcmHandlerObject);
  //lcm.subscribe("TO_CAMERA", &downlcmHandler::tocameraHandleMessage, &downlcmHandlerObject);
  //threadGp.create_thread(boost::bind(&downlcmHandler::rsds_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::todaoyuan_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::topowercon_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::tovehcon_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&downlcmHandler::mobileeyeifo_pub, &downlcmHandlerObject));
  threadGp.create_thread(boost::bind(&downlcmHandler::tocamera_pub, &downlcmHandlerObject));
  //threadGp.create_thread(boost::bind(&uplcmHandler::upstream_pub, &uplcmHandlerObject));
  while(0 == lcm.handle());
  threadGp.join_all();
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }*/
}
