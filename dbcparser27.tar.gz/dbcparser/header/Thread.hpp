#ifndef UPTHREAD_HPP_
#define UPTHREAD_HPP_

#include <thread>
#include <atomic>

class NThread {
public:
  NThread();
  virtual ~NThread();

  void start();
  std::thread::id getId();
  void interrupt();
  bool isInterrupted();
  void join();
  virtual void run();

private:
  std::atomic<bool> isInterript ;
  std::thread th;
};

#endif
