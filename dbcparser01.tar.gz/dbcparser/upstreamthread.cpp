#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "header/upstreamthread.hpp"

upThread::upThread(lcm::LCM lcm) {
  this->lcm = lcm;
}

upThread::~upThread() {

}

void upThread::run() {

  lcm.subscribe("EXAMPLE", NULL, NULL);
  while(0 == lcm.handle());
  return ;
/*
  while(!this->isInterrupted())
  {

  }
  */
}
