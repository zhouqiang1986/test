#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "downstreampub.hpp"

downstreampub::downstreampub(lcmtypes::buffer_data_t *buffer_data, std::mutex *down_mutex) {
  this->buffer_data = buffer_data;
  this->down_mutex = down_mutex;
}

downstreampub::~downstreampub() {

}

int64_t downstreampub::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void downstreampub::run() {
  if(!lcm.good())
  {
    return ;
  }

  while(!this->isInterrupted())
  {
    printf("downstreampub is running\n");
    usleep(50000);//20Hz
    down_mutex->lock();
    buffer_data->utime = getCurrentTime();
    buffer_data->data_length = buffer_data->data.size();
    lcm.publish("DOWNSTREAMDBCSED", buffer_data);
    buffer_data->data.clear();
    buffer_data->data_length = buffer_data->data.size();
    down_mutex->unlock();
  }
}
