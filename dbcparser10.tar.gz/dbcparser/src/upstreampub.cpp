#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "upstreampub.hpp"

upstreampub::upstreampub(lcmtypes::buffer_dbc_t *buffer_dbc, std::mutex *up_mutex) {
  this->buffer_dbc = buffer_dbc;
  this->up_mutex = up_mutex;
}

upstreampub::~upstreampub() {

}

int64_t upstreampub::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void upstreampub::run() {
  if(!lcm.good())
  {
    return ;
  }

  while(!this->isInterrupted())
  {
    printf("upstreampub is running\n");
    usleep(100000);//10Hz
    up_mutex->lock();
    buffer_dbc->utime = getCurrentTime();
    buffer_dbc->data_length = buffer_dbc->data.size();
    lcm.publish("UPSTREAMDBCSED", buffer_dbc);
    buffer_dbc->data.clear();
    buffer_dbc->data_length = buffer_dbc->data.size();
    up_mutex->unlock();
  }
}
