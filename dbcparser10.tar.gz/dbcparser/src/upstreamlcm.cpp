#include  "upstreamlcm.hpp"
#include "signal.hpp"
#include "upstreamthread.hpp"

#include <math.h>

uplcmHandler::uplcmHandler(DBCIterator *pdbc, std::mutex *up_mutex) {
  pdbc_lcm = pdbc;
  this->up_mutex = up_mutex;
}

uint64_t uplcmHandler::doConvert(Signal tSg, uint8_t tmpData[]) {
  uint64_t realValue;
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    uint64_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
    realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
    if(next_len > 0) {
      for(int m=0; m<(data_len-head_len)/8; m++) {
        next_len -= 8;
        realValue |= (tmpData[data_num+m+1]<<next_len);
      }
      realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
    } else {
      realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
    }

  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  head_len;
    uint64_t lShiftS = pow(2,head_len);

    realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);

    if((data_len-next_len) >= 8) {

      for(int n=0; n<(data_len-head_len)/8; n++) {
        realValue |= tmpData[data_num+n+1]<<next_len;
        next_len += 8;
      }
    }

    if((data_len-next_len) > 0) {
      realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;

    }
  }

  return realValue;
}

void uplcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  std::vector< lcmtypes::buffer_message_t > tBuffer_dbc;
  lcmtypes::buffer_message_t buffer_message;

  int32_t pkg_len;
  int32_t pkgNum;
  uint8_t  dataLen;
  uint32_t dataId;
  uint64_t dataData;

  uint8_t *tData = new uint8_t[13];

  pkg_len = rdata->data_length/13;

  for(int i=0; i<pkg_len; i++)
  {
    for(int j=0; j<13; j++) {
      tData[j] = rdata->data[j + i*13];
    }
    dataLen = tData[0];
    dataId = (tData[1]<<24) | (tData[2]<<16) | (tData[3]<<8) | tData[4];

    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = tData[5+k];
    }
    delete []tData;
    buffer_message.sigMap.clear();
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        buffer_message.id = dataId;
        double rValue;
        lcmtypes::map_data_t sigMap;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sigMap.sigName = tSg.getName();
          sigMap.sigValue = rValue;
          buffer_message.sigMap.push_back(sigMap);
        }
        buffer_message.sigCnt = buffer_message.sigMap.size();
        tBuffer_dbc.push_back(buffer_message);
      }

    }

  }

  up_mutex->lock();
  buffer_dbc.data.clear();
  buffer_dbc.data.insert(buffer_dbc.data.begin(), tBuffer_dbc.begin(), tBuffer_dbc.end());
  up_mutex->unlock();

}
