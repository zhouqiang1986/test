#ifndef UPSTREAMTHREAD_HPP_
#define UPSTREAMTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>

#include "Thread.hpp"

class upThread : public NThread {

public:
  upThread();
  virtual ~upThread();

  virtual void run() override;

private:
  lcm::LCM lcm;
};

#endif
