#ifndef UPSTREAMLCM_HPP_
#define UPSTREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>

#include "lcmtypes/buffer_data_t.hpp"

class lcmHandler {
public:
  ~lcmHandler() {};
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::buffer_data_t *msg);
};

#endif
