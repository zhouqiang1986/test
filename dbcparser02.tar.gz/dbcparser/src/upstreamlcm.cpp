#include  "upstreamlcm.hpp"

void lcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *msg)
{

}
