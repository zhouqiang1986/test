#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "upstreamthread.hpp"
#include "upstreamlcm.hpp"

upThread::upThread() {

}

upThread::~upThread() {

}

void upThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  lcmHandler handleObject;
  lcm.subscribe("UPSTREAMDBC", &lcmHandler::handleMessage, &handleObject);
  while(0 == lcm.handle());
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("upThread is running...\n");
    sleep(1);
  }
  */
}
