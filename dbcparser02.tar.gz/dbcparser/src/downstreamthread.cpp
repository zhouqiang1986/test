#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "downstreamthread.hpp"

downThread::downThread() {

}

downThread::~downThread() {

}

void downThread::run() {

  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }
}
