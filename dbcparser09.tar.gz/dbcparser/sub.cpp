#include <lcm/lcm-cpp.hpp>
#include <stdio.h>
#include "lcmtypes/buffer_data_t.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"
class Handler
    {
         public:
             ~Handler() {}

            void handleMessage(const lcm::ReceiveBuffer* rbuf,
                    const std::string& chan,
                    const lcmtypes::buffer_dbc_t* rdata)
            {
              printf("utime:%ld\n", rdata->utime);
              printf("data_length=%d\n", rdata->data_length);
              for(int i=0; i<rdata->data_length; i++) {
                //printf("LongitudeAcc:%lf\n", rdata->data[i].LongitudeAcc);
                //printf("LateralAcc: %lf \n", rdata->data[i].LateralAcce);
              }


            }
    };

    class Handler1
        {
             public:
                 ~Handler1() {}

                void handleMessage(const lcm::ReceiveBuffer* rbuf,
                        const std::string& chan,
                        const lcmtypes::buffer_data_t* rdata)
                {
                    printf("utime=%ld\n", rdata->utime);
                    printf("data_length=%d\n", rdata->data_length);
                  for(int i=0; i<rdata->data_length/13; i++) {
                    printf("len=%d\n", rdata->data[i*13+0]);
                    printf("ID=%d\n", rdata->data[i*13+1]<<24|rdata->data[i*13+2]<<16|rdata->data[i*13+3]<<8|rdata->data[i*13+4]);
                    printf("data[%d]=%x\n", 0, rdata->data[i*13+5]);
                    printf("data[%d]=%x\n", 1, rdata->data[i*13+6]);
                    printf("data[%d]=%x\n", 2, rdata->data[i*13+7]);
                    printf("data[%d]=%x\n", 3, rdata->data[i*13+8]);

                  }
                  //printf("utime:%ld\n", rdata->utime);
                  //printf("LongitudeAcc:%lf\n", rdata->LongitudeAcc);
                  //printf("LateralAcc: %lf \n", rdata->LateralAcce);

                }
        };

int main(int argc, char ** argv)
{
     lcm::LCM lcm;
     if(!lcm.good())
         return 1;

     Handler handlerObject;
     lcm.subscribe("UPSTREAMDBCSED", &Handler::handleMessage, &handlerObject);
     Handler1 handlerObject1;
     lcm.subscribe("DOWNSTREAMDBCSED", &Handler1::handleMessage, &handlerObject1);
     while(0 == lcm.handle());

     return 0;
}
