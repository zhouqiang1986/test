#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "upstreamthread.hpp"
#include "upstreamlcm.hpp"
#include "upstreampub.hpp"

upThread::upThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

upThread::~upThread() {

}

void upThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  uplcmHandler uplcmHandlerObject(pdbc_lcm, &up_mutex);
  lcm.subscribe("UPSTREAMDBCREC", &uplcmHandler::handleMessage, &uplcmHandlerObject);
  upstreampub upPub(&uplcmHandlerObject.buffer_dbc, &up_mutex);
  upPub.start();
  while(0 == lcm.handle());
  upPub.join();
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("upThread is running...\n");
    sleep(1);
  }
  */
}
