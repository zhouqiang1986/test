#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "upstreamthread.hpp"
#include "upstreamlcm.hpp"

upThread::upThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

upThread::~upThread() {

}

void upThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  uplcmHandler uplcmHandlerObject(pdbc_lcm);
  //lcm.subscribe("UPSTREAMDBCREC", &uplcmHandler::handleMessage, &uplcmHandlerObject);
  lcm.subscribe("AD_CAN_RAW_DATA", &uplcmHandler::handleMessage, &uplcmHandlerObject);
  lcm.subscribe("CAN_RSDS_RAW_DATA", &uplcmHandler::rsdsHandleMessage, &uplcmHandlerObject);
  threadGp.create_thread(boost::bind(&uplcmHandler::rsds_pub, &uplcmHandlerObject));
  threadGp.create_thread(boost::bind(&uplcmHandler::upstream_pub, &uplcmHandlerObject));
  while(0 == lcm.handle());
  threadGp.join_all();
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("upThread is running...\n");
    sleep(1);
  }
  */
}
