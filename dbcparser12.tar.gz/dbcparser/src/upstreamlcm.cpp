#include  "upstreamlcm.hpp"
#include "signal.hpp"
#include "upstreamthread.hpp"
#include <math.h>

uplcmHandler::uplcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

int64_t uplcmHandler::getCurrentTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void uplcmHandler::rsds_pub() {
  while(1) {
    //printf("rsds_pub is running\n");
    usleep(100000);//10Hz
    //up_mutex[1].lock();
    //buffer_dbc->utime = getCurrentTime();
    //buffer_dbc->data_length = buffer_dbc->data.size();
    //lcm.publish("UPSTREAMDBCSED", buffer_dbc);
    //buffer_dbc->data.clear();
    //buffer_dbc->data_length = buffer_dbc->data.size();
    //up_mutex[1].unlock();
  }
}

void uplcmHandler::upstream_pub() {
  while(1) {
    //printf("upstreampub is running\n");
    usleep(100000);//10Hz

    up_mutex[0].lock();
    buffer_dbc.utime = getCurrentTime();
    buffer_dbc.data_length = buffer_dbc.data.size();
    lcm.publish("UPSTREAMDBCSED", &buffer_dbc);
    buffer_dbc.data.clear();
    buffer_dbc.data_length = buffer_dbc.data.size();
    up_mutex[0].unlock();
  }
}

uint64_t uplcmHandler::doConvert(Signal tSg, uint8_t tmpData[]) {
  uint64_t realValue;
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    uint64_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
    realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
    if(next_len > 0) {
      for(int m=0; m<(data_len-head_len)/8; m++) {
        next_len -= 8;
        realValue |= (tmpData[data_num+m+1]<<next_len);
      }
      realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
    } else {
      realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
    }

  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  head_len;
    uint64_t lShiftS = pow(2,head_len);

    realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);

    if((data_len-next_len) >= 8) {

      for(int n=0; n<(data_len-head_len)/8; n++) {
        realValue |= tmpData[data_num+n+1]<<next_len;
        next_len += 8;
      }
    }

    if((data_len-next_len) > 0) {
      realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;

    }
  }

  return realValue;
}

void uplcmHandler::rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                       const std::string& chan,
                       const lcmtypes::buffer_data_t *msg)
{ /*
  std::vector< lcmtypes::buffer_message_t > tBuffer_dbc;
  lcmtypes::buffer_message_t buffer_message;

  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }

    buffer_message.sigMap.clear();
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        buffer_message.id = dataId;
        double rValue;
        lcmtypes::map_data_t sigMap;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sigMap.sigName = tSg.getName();
          sigMap.sigValue = rValue;
          buffer_message.sigMap.push_back(sigMap);
        }
        buffer_message.sigCnt = buffer_message.sigMap.size();
        tBuffer_dbc.push_back(buffer_message);
      }

    }

  }
  */
  //up_mutex[1].lock();
  //buffer_dbc.data.clear();
  //buffer_dbc.data.insert(buffer_dbc.data.begin(), tBuffer_dbc.begin(), tBuffer_dbc.end());
  //up_mutex[1].unlock();
}

void uplcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::buffer_data_t *rdata)
{
  std::vector< lcmtypes::buffer_message_t > tBuffer_dbc;
  lcmtypes::buffer_message_t buffer_message;

  for(int i=0; i<(rdata->data_length/13); i++)
  {
    uint32_t dataId = (rdata->data[1+i*13]<<24) | (rdata->data[2+i*13]<<16) | (rdata->data[3+i*13]<<8) | rdata->data[4+i*13];
    uint8_t tmpData[8];
    for(int k=0; k<8; k++) {
      tmpData[k] = rdata->data[5+k+i*13];
    }

    buffer_message.sigMap.clear();
    for(auto tMsg : *pdbc_lcm) {
      if(dataId == tMsg.getId()) {
        buffer_message.id = dataId;
        double rValue;
        lcmtypes::map_data_t sigMap;
        for(auto tSg : tMsg) {
          rValue = doConvert(tSg, tmpData)*tSg.getFactor() + tSg.getOffset();
          sigMap.sigName = tSg.getName();
          sigMap.sigValue = rValue;
          buffer_message.sigMap.push_back(sigMap);
        }
        buffer_message.sigCnt = buffer_message.sigMap.size();
        tBuffer_dbc.push_back(buffer_message);
      }

    }

  }

  up_mutex[0].lock();
  buffer_dbc.data.clear();
  buffer_dbc.data.insert(buffer_dbc.data.begin(), tBuffer_dbc.begin(), tBuffer_dbc.end());
  up_mutex[0].unlock();

}
