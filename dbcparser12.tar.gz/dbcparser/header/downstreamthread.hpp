#ifndef DOWNTHREAD_HPP_
#define DOWNTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>
#include <mutex>

#include "Thread.hpp"
#include "dbciterator.hpp"

class downThread : public NThread {

public:
  downThread(DBCIterator *pdbc);
  virtual ~downThread();

  virtual void run() override;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  std::mutex down_mutex;

};

#endif
