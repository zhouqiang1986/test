#ifndef LateralAcce_HPP_
#define LateralAcce_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>

#include "dbciterator.hpp"
#include "lcmtypes/LateralAcce_t.hpp"

class LateralAcceHandler {
public:
  LateralAcceHandler() {};
  LateralAcceHandler(DBCIterator *pdbc);
  ~LateralAcceHandler() {};
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::LateralAcce_t *msg);

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
  uint32_t dataId;
};

#endif
