#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "downstreamthread.hpp"
#include "downstreamlcm.hpp"

downThread::downThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

downThread::~downThread() {

}

void downThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  downlcmHandler downlcmHandlerObject(pdbc_lcm);
  lcm.subscribe("DOWNSTREAMDBCREC", &downlcmHandler::handleMessage, &downlcmHandlerObject);
  while(0 == lcm.handle());
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }*/
}
