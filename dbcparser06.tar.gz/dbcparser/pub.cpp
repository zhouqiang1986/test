#include <lcm/lcm-cpp.hpp>
#include <iostream>

#include "lcmtypes/buffer_data_t.hpp"
#include "lcmtypes/wey_data_t.hpp"

int main(int argc, char ** argv)
{
     lcm::LCM lcm;
     if(!lcm.good())
         return 1;

     lcmtypes::buffer_data_t my_data;
     my_data.utime = 4;
     my_data.data_length = 13;
     my_data.data.resize(my_data.data_length);
       my_data.data[0] = 0x0d;
       my_data.data[1] = 0x00;
       my_data.data[2] = 0x00;
       my_data.data[3] = 0x02;
       my_data.data[4] = 0x45;
       my_data.data[5] = 0x69;
       my_data.data[6] = 0xff;
       my_data.data[7] = 0x8e;
       my_data.data[8] = 0xac;
       my_data.data[9] = 0x00;
       my_data.data[10] = 0x00;
       my_data.data[11] = 0x00;
       my_data.data[12] = 0x00;
       //lcm.publish("UPSTREAMDBCREC", &my_data);

    lcmtypes::wey_data_t wey_data;
    wey_data.LateralAcce = 14.20152;
    wey_data.LongitudeAcc = 5.0003;
    lcm.publish("DOWNSTREAMDBCREC", &wey_data);

     return 0;
}
