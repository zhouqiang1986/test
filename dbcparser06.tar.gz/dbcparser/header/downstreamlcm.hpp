#ifndef DOWNSTREAMLCM_HPP_
#define DOWNSTREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>

#include "dbciterator.hpp"
#include "lcmtypes/wey_data_t.hpp"

class downlcmHandler {
public:
  downlcmHandler() {};
  downlcmHandler(DBCIterator *pdbc);
  ~downlcmHandler() {};
  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::wey_data_t *msg);

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;

private:
  void dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue);
};

#endif
