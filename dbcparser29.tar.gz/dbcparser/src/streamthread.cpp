#include <iostream>
#include <stdio.h>
#include <unistd.h>

#include "streamthread.hpp"
#include "streamlcm.hpp"

streamThread::streamThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

streamThread::~streamThread() {

}

void streamThread::run() {
  if(!lcm.good())
  {
    return ;
  }
  lcmHandler lcmHandlerObject(pdbc_lcm);
  //lcm.subscribe("AD_CAN_RAW_DATA", &lcmHandler::handleMessage, &lcmHandlerObject);
  std::map<uint32_t, std::map<std::string, double>> k_v;
  cfgListIte_t cfgite;
  msgsDict_t msgite;
  for(msgite=pdbc_lcm->msgsDict.begin(); msgite != pdbc_lcm->msgsDict.end(); msgite++) {
    if((cfgite=pdbc_lcm->cfgList->find(msgite->first)) != pdbc_lcm->cfgList->end()) {
      if(cfgite->second.find("lcm_channel") != cfgite->second.end()) {
        std::string lcm_channel = cfgite->second.find("lcm_channel")->second;
        if(!lcm_channel.empty() && lcm_channel.size()>1) {
          std::cout<<"!channel:"<<lcm_channel<<std::endl;
          //std::cout<<"!sensor:"<<cfgite->first<<std::endl;
          lcmHandlerObject.channelToSensor.insert(std::make_pair(lcm_channel, cfgite->first));
          lcmHandlerObject.dbcDict.insert(std::make_pair(lcm_channel, k_v));
          lcm.subscribe(lcm_channel, &lcmHandler::mobileeyeifoHandleMessage, &lcmHandlerObject);
        }
      }
      if(cfgite->second.find("lcm_rx_channel") != cfgite->second.end()) {
        std::string lcm_channel = cfgite->second.find("lcm_rx_channel")->second;
        if(!lcm_channel.empty() && lcm_channel.size()>1) {
          if(msgite->first == "Sensor_CAN_MOBILE_RX") {
            //std::cout<<"!channel:"<<lcm_channel<<"   size:"<<lcm_channel.size()<<std::endl;
            //lcm.subscribe(lcm_channel, &downlcmHandler::tocameraHandleMessage, &downlcmHandlerObject);
            threadGp.create_thread(boost::bind(&lcmHandler::tocamera_pub, &lcmHandlerObject));
          }

        }
      }
    }
  }
  /*
  lcm.subscribe("CAN_RSDS_RAW_DATA", &uplcmHandler::rsdsHandleMessage, &uplcmHandlerObject);
  lcm.subscribe("ESR_REAR_RAW_DATA", &uplcmHandler::esrrearHandleMessage, &uplcmHandlerObject);
  lcm.subscribe("CAN_ESR_FRONT_RAW_DATA", &uplcmHandler::canesrfrontHandleMessage, &uplcmHandlerObject);
  lcm.subscribe("AD_CAN_RAW_DATA", &uplcmHandler::adcanHandleMessage, &uplcmHandlerObject);
  lcm.subscribe("CAN_MOBILE_TX", &uplcmHandler::mobileeyeifoHandleMessage, &uplcmHandlerObject);
  lcm.subscribe("CAN_MOBILE_RX", &uplcmHandler::mobileeyeconHandleMessage, &uplcmHandlerObject);*/
  //threadGp.create_thread(boost::bind(&uplcmHandler::rsds_pub, &uplcmHandlerObject));
  //threadGp.create_thread(boost::bind(&uplcmHandler::esrrear_pub, &uplcmHandlerObject));
  //threadGp.create_thread(boost::bind(&uplcmHandler::canesrfront_pub, &uplcmHandlerObject));
  //threadGp.create_thread(boost::bind(&uplcmHandler::adcan_pub, &uplcmHandlerObject));
  //threadGp.create_thread(boost::bind(&lcmHandler::mobileeyeifo_pub, &lcmHandlerObject));
  //threadGp.create_thread(boost::bind(&uplcmHandler::mobileeyecon_pub, &uplcmHandlerObject));
  //threadGp.create_thread(boost::bind(&lcmHandler::upstream_pub, &lcmHandlerObject));

  while(0 == lcm.handle());
  threadGp.join_all();
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("upThread is running...\n");
    sleep(1);
  }
  */
}
