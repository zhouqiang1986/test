#ifndef STREAMLCM_HPP_
#define STREAMLCM_HPP_

#include <iostream>
#include <lcm/lcm-cpp.hpp>
#include <mutex>
#include <boost/thread/mutex.hpp>
#include <string>
#include <map>
#include "dbciterator.hpp"
#include "signal.hpp"
#include "lcmtypes/buffer_data_t.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"
#include <math.h>
#include <stdio.h>
#include <algorithm>

class lcmHandler {

#define deg2rad(x) ((atan(1.0)*(x))/45.0)

typedef std::map<std::string, std::map<uint32_t, std::map<std::string, double>>> DBCDICT_t;
//typedef std::map<std::string, std::map<uint32_t, std::map<std::string, double>>>::iterator DBCDICT_Ite;
typedef std::map<uint32_t, std::map<std::string, double>> msgList_t;
typedef std::map<uint32_t, std::map<std::string, double>>::iterator msgList_Ite;

typedef std::map<std::string, std::map<std::string, std::string>> cfgList_t;
typedef std::map<std::string, std::map<std::string, std::string>>::iterator cfgListIte_t;
typedef std::map<std::string, std::string> channelToSensor_t;
typedef std::map<std::string, std::string>::iterator cfgSigIte_t;
//typedef std::map<std::string, std::vector<Message>> messages_t;
//typedef std::map<std::string, std::vector<Message>>::iterator msgIte_t;
typedef std::map<uint32_t, std::map<std::string, struct SSignal>> messages_t;
typedef std::map<uint32_t, std::map<std::string, struct SSignal>>::iterator msgIte_t;
typedef std::map<std::string, struct SSignal> sigs_t;
typedef std::map<std::string, struct SSignal>::iterator sigIte_t;

public:
  lcmHandler() {};
  lcmHandler(DBCIterator *pdbc);
  virtual ~lcmHandler() {};

  void handleMessage(const lcm::ReceiveBuffer *buf,
                     const std::string& chan,
                     const lcmtypes::buffer_data_t *msg);
  void rsdsHandleMessage(const lcm::ReceiveBuffer *buf,
                         const std::string& chan,
                         const lcmtypes::buffer_data_t *msg);
  void esrrearHandleMessage(const lcm::ReceiveBuffer *buf,
                            const std::string& chan,
                            const lcmtypes::buffer_data_t *msg);
  void canesrfrontHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void adcanHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void mobileeyeifoHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);
  void mobileeyeconHandleMessage(const lcm::ReceiveBuffer *buf,
                                const std::string& chan,
                                const lcmtypes::buffer_data_t *msg);

public:
  lcmtypes::buffer_dbc_t buffer_dbc;
  DBCDICT_t dbcDict;
  channelToSensor_t channelToSensor;

private:
  //lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
  DBCIterator *pdbc_lcm;
  std::mutex up_mutex[10];
  //double obj_buf[64][15];

private:
  double doGetRealValue(messages_t& dbcList, uint32_t msgId, std::string str, uint8_t tmpData[]);
  uint64_t doConvert(struct SSignal& tSg, uint8_t tmpData[]);
  void dorConvert(struct SSignal& tSg, uint8_t tData[], uint64_t hexValue);
  int64_t getCurrentTime();
  void getHexDataBuf(messages_t& dbcList, uint8_t tData[], uint32_t msgId, std::string str, double mValue);
public:
  void rsds_pub();
  void esrrear_pub();
  void canesrfront_pub();
  void adcan_pub();
  void mobileeyeifo_pub();
  void mobileeyecon_pub();
  void tocamera_pub();
  void upstream_pub();

private:
  uint8_t send_mobile_eye_cmd_flag;
  double LongitudeAcc_Val;
  double LateralAcce_Val;
  double VehDynYawRate_Val;
  double RLWheelDriveDirection_Val;
  double RLWheelSpd_Val;
  double RRWheelDriveDirection_Val;
  double RRWheelSpd_Val;
  double VehicleSpd_Val;
};

#endif
