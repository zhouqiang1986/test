# /usr/bin/python/
# coding:utf-8

#######################################################
#
#     完成毫米波雷达的数据解析和处理lcm发送
#                                        ljs 2018.8.13
#######################################################
import sys
sys.path.append('../data/')
sys.path.append('../lib/')
sys.path.append('../third_party')

import math
import struct
import threading
import numpy as np
import time
import cantools
import lcm
import queue

import IV_coordinator
from IV_Esr_Setting import InfoIni
from lcmtypes import buffer_data_t,esr_obj_t, esr_objs_t


class EsrSensor(object):
    def __init__(self, radar_info):
        self.who_receive,self.who_send = radar_info['lcm_subscribe_channel'],radar_info['lcm_publish_channel']
        self.db = cantools.db.load_file('../data/dbc/ESR.dbc')
        self.obj_status_dict = {'New_Coasted_Target':7, 'Invalid_Coasted_Target':6, 'Merged_Target':5, 'Coasted_Target':4,
                                'Updated_Target':3, 'New_Updated_Target':2, 'New_Target':1, 'No_Target':0}
        self.receive_canID_list = [msg.frame_id for msg in self.db.messages]
        # 雷达安装位置坐标系相对整车坐标系的变换参数
        self.xoffset, self.yoffset, self.zoffset = float(radar_info['x_offset']), float(radar_info['y_offset']), \
                                                   float(radar_info['z_offset'])
        self.pitch, self.yaw, self.roll = float(radar_info['pitch']), float(radar_info['yaw']), \
                                          float(radar_info['roll'])
        self.set_Rm()
        self.set_Tm()

        self.objectdata = np.zeros([64, 15])  # 障碍目标缓冲[角度，距离，速度，x,y,z,x0,y0,z0,count,vx,accy,width,obj_id, status]
        self.validobjectdata = self.objectdata  # 识别跟踪到的有效目标

        self.msg_queue = queue.Queue()
        self.lc = lcm.LCM("udpm://239.255.76.67:7667?ttl=1")
        self.subscription=self.lc.subscribe(self.who_receive, self.Esr_handler)

        self.esr_start_protocol()

    def start(self):
        esr_thread = threading.Thread(target=self.run,name=self.who_receive)
        esr_thread.daemon = True
        esr_thread.start()

    def run(self):
        try:
            while True:
                self.lc.handle()
        except KeyboardInterrupt:
            pass

    def set_Rm(self):
        self.Rx = IV_coordinator.MatrixR_RX(math.radians(self.pitch))
        self.Ry = IV_coordinator.MatrixR_RY(math.radians(self.roll))
        self.Rz = IV_coordinator.MatrixR_RZ(math.radians(self.yaw))

        self.RM = np.dot(np.dot(self.Rx, self.Ry), self.Rz)

    def set_Tm(self):

        self.TM = np.array([self.xoffset, self.yoffset, self.zoffset])

    def Esr_handler(self,channel,data):
        msg = buffer_data_t.decode(data)
        d, m = divmod(msg.data_length, 13)
        if d > 0 and m == 0:
            for st in range(0, d * 13, 13):
                _, msg_id = struct.unpack('>BI', msg.data[st:st + 5])
                if msg_id in self.receive_canID_list:
                    self.msg_queue.put([msg_id, msg.data[st + 5:st + 13]])

    def esr_start_protocol(self):
        thd_esr_start = threading.Thread(target=self._do_esr, name='ESR_Start_Thread')
        thd_esr_start.setDaemon(True)
        thd_esr_start.start()

    def _do_esr(self):
        while True:
            try:
                msg_id, data = self.msg_queue.get()
                self.msg_decode(msg_id, data)
            except KeyboardInterrupt:
                pass

    def msg_decode(self, msg_id, msg_data):
        data_index = msg_id - 0x500
        if 0 <= data_index < 64:
            msg_dict = self.db.decode_message(msg_id, msg_data)

            self.objectdata[data_index, 13] = data_index    #obj_id
            if msg_dict['CAN_TX_TRACK_RANGE']==0 or msg_dict['CAN_TX_TRACK_STATUS']==0:
                # 如果角度和距离都为0 则为无效数据,没有识别到有效障碍，该索引缓冲清零
                self.objectdata[data_index, :] = 0
            else:
                # 如果角度或距离不为0 则为有效数据,识别到有效障碍，该索引障碍计数累加1
                self.objectdata[data_index, 9] += 1

                self.objectdata[data_index, 0] =  msg_dict['CAN_TX_TRACK_ANGLE']  # angle ° -51.2 to 51.1  度
                self.objectdata[data_index, 1] =  msg_dict['CAN_TX_TRACK_RANGE']  # distance m 0-204.7 m
                self.objectdata[data_index, 2] =  msg_dict['CAN_TX_TRACK_RANGE_RATE']  # speed m/s -81.92 to 81.91 m/s
                self.objectdata[data_index, 10] = msg_dict['CAN_TX_TRACK_LAT_RATE']  # vx
                self.objectdata[data_index, 11] = msg_dict['CAN_TX_TRACK_RANGE_ACCEL']  # accy
                self.objectdata[data_index, 12] = msg_dict['CAN_TX_TRACK_WIDTH']  # width
                self.objectdata[data_index, 14] = self.obj_status_dict[msg_dict['CAN_TX_TRACK_STATUS']]  # obj status
                # status: 7: 'New_Coasted_Target', 6: 'Invalid_Coasted_Target', 5: 'Merged_Target', 4: 'Coasted_Target',
                #  3: 'Updated_Target', 2: 'New_Updated_Target', 1: 'New_Target', 0: 'No_Target'

        if data_index == 63:
            # 收到一帧数据
            # 雷达坐标系下 x y z 坐标变换前的位置
            np.deg2rad(self.objectdata[:, 0], self.objectdata[:, 0])
            self.objectdata[:, 3] = self.objectdata[:, 1] * np.sin(self.objectdata[:, 0])
            self.objectdata[:, 4] = self.objectdata[:, 1] * np.cos(self.objectdata[:, 0])
            self.objectdata[data_index, 5] = 0

            # 整车坐标系下 x y z 即坐标变换后的位置
            self.objectdata[:, 6:9] = np.dot(self.objectdata[:, 3:6], self.RM) + self.TM
            # 识别到的有效障碍，条件：连续识别次数大于n=10
            self.validobjectdata = self.objectdata[self.objectdata[:, 9] > 2]  #

            esr_objs = esr_objs_t()
            for data in self.validobjectdata:
                obj = esr_obj_t()
                obj.obj_id, obj.obj_x, obj.obj_y, obj.obj_vx, obj.obj_vy, obj.obj_acc, obj.obj_width, obj.obj_status = \
                    int(data[13]),data[6], data[7], data[10], data[2], data[11], data[12], int(data[14])
                esr_objs.objs.append(obj)
                # if self.who_send == "REAR_ESR_WHOLE_DATA":
                #     print(obj.obj_x, obj.obj_y, obj.obj_status)
            esr_objs.objs_count = esr_objs.objs.__len__()
            # print(self.who_send)
            self.lc.publish(self.who_send, esr_objs.encode())

#

def main():
    try:
        radar_parameter = InfoIni()
        front_esr = EsrSensor(radar_parameter.info['Front_ESR_Parameter'])
        front_esr.start()
        rear_esr = EsrSensor(radar_parameter.info['Rear_ESR_Parameter'])
        rear_esr.start()
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        sys.exit()



if __name__ == '__main__':
    main()
