#include <lcm/lcm-cpp.hpp>
#include <iostream>
#include <unistd.h>

#include "lcmtypes/buffer_data_t.hpp"
#include "lcmtypes/buffer_dbc_t.hpp"

int main(int argc, char ** argv)
{
     lcm::LCM lcm("udpm://239.255.76.67:7667?ttl=1");
     if(!lcm.good())
         return 1;

     lcmtypes::buffer_data_t my_data;
     my_data.utime = 4;
     my_data.data_length = 26;
     my_data.data.resize(my_data.data_length);
       my_data.data[0] = 0x0d;
       my_data.data[1] = 0x00;
       my_data.data[2] = 0x00;
       my_data.data[3] = 0x05;
       my_data.data[4] = 0x3f;
       //my_data.data[3] = 0x02;
       //my_data.data[4] = 0x45;
       my_data.data[5] = 0x69;
       my_data.data[6] = 0xff;
       my_data.data[7] = 0x8e;
       my_data.data[8] = 0xac;
       my_data.data[9] = 0x00;
       my_data.data[10] = 0x00;
       my_data.data[11] = 0x00;
       my_data.data[12] = 0x00;

       my_data.data[13] = 0x0d;
       my_data.data[14] = 0x00;
       my_data.data[15] = 0x00;
       my_data.data[16] = 0x05;
       my_data.data[17] = 0x40;
       //my_data.data[16] = 0x02;
       //my_data.data[17] = 0x31;
       my_data.data[18] = 0x07;
       my_data.data[19] = 0x00;
       my_data.data[20] = 0x11;
       my_data.data[21] = 0x95;
       my_data.data[22] = 0x00;
       my_data.data[23] = 0x00;
       my_data.data[24] = 0x00;
       my_data.data[25] = 0x00;
       while(1) {
        usleep(10000);//100hz
        lcm.publish("CAN_ESR_REAR_DAOYUAN_RAW_DATA", &my_data);
        lcm.publish("CAN_ESR_FRONT_RAW_DATA", &my_data);
      }

    lcmtypes::buffer_dbc_t buffer_dbc;
    lcmtypes::buffer_message_t buffer_message;
    lcmtypes::map_data_t sigMap;
    buffer_dbc.utime = 123432;
    buffer_dbc.data_length = 2;

    sigMap.sigName = "LongitudeAcc";
    sigMap.sigValue = 5.0003;
    buffer_message.id = 581;
    buffer_message.sigCnt = 2;
    buffer_message.sigMap.push_back(sigMap);
    sigMap.sigName = "LateralAcce";
    sigMap.sigValue = 14.201520;
    buffer_message.sigMap.push_back(sigMap);
    buffer_dbc.data.push_back(buffer_message);

    buffer_message.sigMap.clear();
    sigMap.sigName = "FRWheelSpd";
    sigMap.sigValue = 253.181250;
    buffer_message.id = 561;
    buffer_message.sigCnt = 1;
    buffer_message.sigMap.push_back(sigMap);
    buffer_dbc.data.push_back(buffer_message);

    //while(1) {
    //  usleep(10000);//100Hz
    //  lcm.publish("TO_VEHICLE_CONTROL", &buffer_dbc);
    //}

     return 0;
}
