/*
 * dbctree.cpp
 *
 *  Created on: 04.10.2013
 *      Author: downtimes
 */

#include "dbciterator.hpp"

#include <limits>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <dirent.h>

DBCIterator::DBCIterator(cfgList_t *cfgList) {
	this->cfgList = cfgList;
	std::string filePath = "../dbc/";
	getFiles(filePath);
	//messageList.clear();
	msgsDict.clear();
	std::map<std::string, std::map<std::string, std::string>>::iterator exp;
	std::map<std::string, std::string> dbcfPath;
	exp = cfgList->begin();
	while(exp != cfgList->end()) {
		dbcfPath = exp->second;
		std::map<std::string, std::string>::iterator ite = dbcfPath.find("dbc");
		if((ite != dbcfPath.end()) && (ite->second.substr(ite->second.find_last_of('.') + 1).compare("dbc") == 0)) {
			std::string tfile = filePath+ite->second;
			//std::cout<<tfile<<std::endl;
			for(auto filename : fileList) {
				if(0 == filename.compare(tfile)) {
					std::string sensor = exp->first;
					std::ifstream file(tfile);
					if (file) {
						init(file, sensor);
					} else {
						throw std::invalid_argument("The File could not be opened");
					}
					file.close();
				}
			}
		}
		exp++;
	}
}
/*
DBCIterator::DBCIterator(std::istream& stream) {
	init(stream);
}*/

void DBCIterator::init(std::istream& stream, std::string& str) {

	//std::vector<Message> messages;
	std::map<uint32_t, std::map<std::string, struct SSignal>> messages;
	std::map<std::string, struct SSignal> sIgs;
	struct SSignal sIg;
	do {
		Message msg;
		stream >> msg;
		if (stream.fail()) {
			stream.clear();
			stream.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		} else {
			for(auto msIg : msg) {
				sIg.order = msIg.order;
				sIg.startBit = msIg.startBit;
				sIg.length = msIg.length;
				sIg.sign = msIg.sign;
				sIg.minimum = msIg.minimum;
				sIg.maximum = msIg.maximum;
				sIg.factor = msIg.factor;
				sIg.offset = msIg.offset;
				sIg.unit = msIg.unit;
				sIg.multiplexor = msIg.multiplexor;
				sIg.multiplexNum = msIg.multiplexNum;
				sIg.to = msIg.to;
				sIgs[msIg.name] = sIg;
			}
			messages[msg.id] = sIgs;
			sIgs.clear();
		}
	} while (!stream.eof());
	//messageList.insert(std::make_pair(str, messages));
	msgsDict.insert(std::make_pair(str, messages));
}

void DBCIterator::getFiles(const std::string& filePath)
{
	DIR *dp;
	struct dirent *dirp;
	if((dp = opendir(filePath.c_str())) == NULL)
	{
		std::cout << "Can not open " << filePath << std::endl;
		return ;
	}

	while((dirp = readdir(dp)) != NULL)
	{
		std::string filename = dirp->d_name;
		std::string suffixStr = filename.substr(filename.find_last_of('.') + 1);
		if(dirp -> d_type == 8) // 4 means catalog; 8 means file; 0 means unknown
		{
			if(suffixStr.compare("dbc") == 0)
			{
				std::string all_path = filePath + dirp->d_name;
				fileList.push_back(all_path);

			}
			else
			{

			}
		}
		else
		{

		}
	}
	closedir(dp);
	//for(auto file : fileList) {
	//	std::cout << file << std::endl;
	//}
}
