/*
 * dbctree.cpp
 *
 *  Created on: 04.10.2013
 *      Author: downtimes
 */

#include "dbciterator.hpp"

#include <limits>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <dirent.h>

DBCIterator::DBCIterator(const std::string& filePath) {
	getFiles(filePath);
	messageList.clear();
	for(auto files : fileList) {
		std::ifstream file(files);
		if (file) {
			init(file);
		} else {
			throw std::invalid_argument("The File could not be opened");
		}
		file.close();
	}
}

DBCIterator::DBCIterator(std::istream& stream) {
	init(stream);
}

void DBCIterator::init(std::istream& stream) {

	std::vector<Message> messages;
	do {
		Message msg;
		stream >> msg;
		if (stream.fail()) {
			stream.clear();
			stream.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		} else {
			messages.push_back(msg);
		}
	} while (!stream.eof());
	messageList.insert(messageList.end(), messages.begin(), messages.end());
}

void DBCIterator::getFiles(const std::string& filePath)
{
	DIR *dp;
	struct dirent *dirp;
	if((dp = opendir(filePath.c_str())) == NULL)
	{
		std::cout << "Can not open " << filePath << std::endl;
		return ;
	}

	while((dirp = readdir(dp)) != NULL)
	{
		std::string filename = dirp->d_name;
		std::string suffixStr = filename.substr(filename.find_last_of('.') + 1);
		if(dirp -> d_type == 8) // 4 means catalog; 8 means file; 0 means unknown
		{
			if(suffixStr.compare("dbc") == 0)
			{
				std::string all_path = filePath + "/" + dirp->d_name;
				fileList.push_back(all_path);

			}
			else
			{

			}
		}
		else
		{

		}
	}
	closedir(dp);
	for(auto file : fileList) {
		std::cout << file << std::endl;
	}
}
