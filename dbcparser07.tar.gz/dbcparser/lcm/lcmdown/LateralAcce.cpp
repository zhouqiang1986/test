#include  "LateralAcce.hpp"
#include "signal.hpp"
#include <math.h>

LateralAcceHandler::LateralAcceHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
  dataId = 581;
}

void LateralAcceHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::LateralAcce_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  double LateralAcce = rdata->LateralAcce;

  for(auto tMsg : *pdbc_lcm) {
    if(dataId == tMsg.getId()) {
      for(auto tSg : tMsg) {
        std::string sgName = tSg.getName();
        if(0 == sgName.compare("LateralAcce")) {
          uint64_t hexValue = (LateralAcce-tSg.getOffset())/tSg.getFactor();

          if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
            uint8_t  data_len = tSg.getLength();
            uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
            uint8_t  data_num = tSg.getStartbit()/8;
            uint8_t  next_len =  data_len-head_len;
            hexValue = hexValue&(pow(2,data_len)-1);
            if(next_len > 0) {

            } else {
              hexValue
            }



          } else {

          }
        }
        uint64_t realValue;
        double rValue;
        if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
          uint8_t  data_len = tSg.getLength();
          uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
          uint8_t  data_num = tSg.getStartbit()/8;
          uint8_t  next_len =  data_len-head_len;
          uint32_t lShiftF = pow(2,tSg.getStartbit()%8+1+next_len);
          realValue = (tmpData[data_num]<<next_len)&(lShiftF-1);
          if(next_len > 0) {
            for(int m=0; m<(data_len-head_len)/8; m++) {
              next_len -= 8;
              realValue |= (tmpData[data_num+m+1]<<next_len);
            }
            realValue |= tmpData[data_num+(data_len-head_len)/8+1]>>(8-next_len);
          } else {
            realValue = realValue>>(tSg.getStartbit()%8+1-data_len);
          }

        } else {
          uint8_t  data_len = tSg.getLength();
          uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
          uint8_t  data_num = tSg.getStartbit()/8;
          uint8_t  next_len =  head_len;
          uint32_t lShiftS = pow(2,head_len);
          realValue = (tmpData[data_num]>>tSg.getStartbit()%8)&(lShiftS-1);
          if(next_len > 8) {
            for(int n=0; n<(data_len-head_len)/8; n++) {
              realValue |= tmpData[data_num+n+1]<<next_len;
              next_len += 8;
            }
            realValue |= (tmpData[data_num+(data_len-head_len)/8+1]>>(8-(data_len-next_len)))<<next_len;
          } else {

          }

        }
        if(Sign::UNSIGNED == tSg.getSign()) {
          rValue = realValue*tSg.getFactor() + tSg.getOffset();

        } else {
          rValue = (int64_t)realValue*tSg.getFactor() + tSg.getOffset();
        }
        std::cout << "SG_Name: " << tSg.getName() <<std::endl;
        printf(" Value = %lf\n", rValue);
      }
    }

  }

  //lcm.publish("UPSTREAMDBCSED", rdata);
}
