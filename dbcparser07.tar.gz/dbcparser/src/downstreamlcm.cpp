#include  "downstreamlcm.hpp"
#include "signal.hpp"

#include <math.h>

downlcmHandler::downlcmHandler(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

void downlcmHandler::dorConvert(Signal tSg, uint8_t tData[], uint64_t hexValue) {
  if(ByteOrder::MOTOROLA == tSg.getByteOrder()) { //bigen
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (tSg.getStartbit()%8+1)<data_len?(tSg.getStartbit()%8+1):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue>>next_len)<<(tSg.getStartbit()%8+1-head_len);
    if(next_len >= 8) {
      for(int i=0; i<(data_len-head_len)/8; i++) {
        next_len -= 8;
        tData[data_num+i+1] = (hexValue>>next_len)&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= (hexValue&((uint64_t)pow(2,next_len)-1))<<(8-next_len);
    }
  } else {
    uint8_t  data_len = tSg.getLength();
    uint8_t  head_len = (8-tSg.getStartbit()%8)<data_len?(8-tSg.getStartbit()%8):data_len;
    uint8_t  data_num = tSg.getStartbit()/8;
    uint8_t  next_len =  data_len-head_len;
    hexValue = hexValue&((uint64_t)pow(2,data_len)-1);
    tData[data_num] |= (hexValue&((uint64_t)pow(2,head_len)-1))<<(tSg.getStartbit()%8);
    if(next_len >= 8) {
      for(int j=0; j<(data_len-head_len)/8; j++) {
        next_len -= 8;
        tData[data_num+j+1] = (hexValue>>(head_len+j*8))&0xff;
      }
    }
    if(next_len > 0) {
      tData[data_num+(data_len-head_len)/8+1] |= hexValue>>(data_len-next_len);
    }
  }
}

void downlcmHandler::handleMessage(const lcm::ReceiveBuffer *buf,
                   const std::string& chan,
                   const lcmtypes::wey_data_t *rdata)
{
  if(!lcm.good())
  {
    return ;
  }

  int32_t pkg_len = rdata->data_length;
  //printf(" LateralAcce = %lf\n", LateralAcce);
  //printf(" LongitudeAcc = %lf\n", LongitudeAcc);
  for(int i=0; i<pkg_len; i++){
      double LateralAcce = rdata->data[i].LateralAcce;
      double LongitudeAcc = rdata->data[i].LongitudeAcc;
      buffer_data.data.clear();
      for(auto tMsg : *pdbc_lcm) {
        if(581 == tMsg.getId()) {
          uint8_t tData[8] = {0};
          for(auto tSg : tMsg) {
            std::string sgName = tSg.getName();
            uint64_t hexValue;
            if(0 == sgName.compare("LateralAcce")) {
              hexValue = (LateralAcce-tSg.getOffset())/tSg.getFactor();
              //printf(" LateralAcce = %ld\n", hexValue);
              dorConvert(tSg, tData, hexValue);
            } else if(0 == sgName.compare("LongitudeAcc")) {
              hexValue = (LongitudeAcc-tSg.getOffset())/tSg.getFactor();
              //printf(" LongitudeAcc = %ld\n", hexValue);
              dorConvert(tSg, tData, hexValue);
            }
          }
          //for(int j=0; j<8; j++) {
            //printf("tdata[%d]=%x\n", j, tData[j]);
          //}
          std::vector<uint8_t> tpData;
          tpData.push_back(8);
          tpData.push_back((tMsg.getId()>>24)&0xff);
          tpData.push_back((tMsg.getId()>>16)&0xff);
          tpData.push_back((tMsg.getId()>>8)&0xff);
          tpData.push_back(tMsg.getId()&0xff);
          for(int k=0; k<8; k++) {
            tpData.push_back(tData[k]);
          }
          buffer_data.data.insert(buffer_data.data.end(), tpData.begin(), tpData.end());
        }
      }
  }

}
