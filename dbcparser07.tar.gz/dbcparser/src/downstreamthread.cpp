#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <signal.h>

#include "downstreamthread.hpp"
#include "downstreamlcm.hpp"
#include "downstreampub.hpp"

downThread::downThread(DBCIterator *pdbc) {
  pdbc_lcm = pdbc;
}

downThread::~downThread() {

}

void downThread::run() {
  if(!lcm.good())
  {
    return ;
  }

  downlcmHandler downlcmHandlerObject(pdbc_lcm);
  lcm.subscribe("DOWNSTREAMDBCREC", &downlcmHandler::handleMessage, &downlcmHandlerObject);
  downstreampub downPub(&downlcmHandlerObject.buffer_data);
  downPub.start();
  while(0 == lcm.handle());
  downPub.join();
  return ;
  /*
  while(!this->isInterrupted())
  {
    printf("down_thread is running\n");
    sleep(1);
  }*/
}
