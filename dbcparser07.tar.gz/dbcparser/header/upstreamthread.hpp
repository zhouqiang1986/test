#ifndef UPSTREAMTHREAD_HPP_
#define UPSTREAMTHREAD_HPP_

#include <lcm/lcm-cpp.hpp>

#include "Thread.hpp"
#include "dbciterator.hpp"

class upThread : public NThread {

public:
  upThread() {};
  upThread(DBCIterator *pdbc);
  virtual ~upThread();

  virtual void run() override;

public:
  static std::mutex up_mutex;

private:
  lcm::LCM lcm;
  DBCIterator *pdbc_lcm;
};

#endif
